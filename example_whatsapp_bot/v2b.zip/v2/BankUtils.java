package net.runelite.client.plugins.v2;

import static java.lang.Math.ceil;

import java.awt.*;
import java.util.Collection;
import java.util.concurrent.ThreadLocalRandom;
import javax.inject.Inject;
import javax.inject.Singleton;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.InventoryID;
import net.runelite.api.Item;
import net.runelite.api.ItemContainer;
import net.runelite.api.queries.BankItemQuery;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.api.widgets.WidgetItem;
import net.runelite.client.callback.ClientThread;
import net.runelite.client.game.ItemManager;

@Slf4j
@Singleton
public class BankUtils {
    @Inject
    private Client client;

    private Sniper sniper;

    @Inject
    private InventoryUtils inventory;

    @Inject
    private ItemManager itemManager;

    @Inject
    private ClientThread clientThread;

    public boolean isDepositBoxOpen() {
        return client.getWidget(WidgetInfo.DEPOSIT_BOX_INVENTORY_ITEMS_CONTAINER) != null;
    }

    public boolean isOpen() {
        return client.getItemContainer(InventoryID.BANK) != null;
    }

    public void close() {
        if (!isOpen()) {
            return;
        }
        Widget bankCloseWidget = client.getWidget(WidgetInfo.BANK_PIN_EXIT_BUTTON);
        if (bankCloseWidget != null) {
            Sniper.TargetWidget t = new Sniper.TargetWidget(bankCloseWidget);
            sniper.cSnipe(t, 1, 3000);
        } else {
            sniper.cTypeTabKey(Sniper.TabKey.INVENTORY);
        }
    }

    //doesn't NPE
    public boolean contains(String itemName) {
        if (isOpen()) {
            ItemContainer bankItemContainer = client.getItemContainer(InventoryID.BANK);

            for (Item item : bankItemContainer.getItems()) {
                if (itemManager.getItemComposition(item.getId()).getName().equalsIgnoreCase(itemName)) {
                    return true;
                }
            }
        }
        return false;
    }

    //doesn't NPE
    public boolean containsAnyOf(int... ids) {
        if (isOpen()) {
            ItemContainer bankItemContainer = client.getItemContainer(InventoryID.BANK);
            return new BankItemQuery().idEquals(ids).result(client).size() > 0;
        }
        return false;
    }

    public boolean containsAnyOf(Collection<Integer> ids) {
        if (isOpen()) {
            ItemContainer bankItemContainer = client.getItemContainer(InventoryID.BANK);
            for (int id : ids) {
                if (new BankItemQuery().idEquals(ids).result(client).size() > 0) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    //Placeholders count as being found
    public boolean contains(String itemName, int minStackAmount) {
        if (isOpen()) {
            ItemContainer bankItemContainer = client.getItemContainer(InventoryID.BANK);

            for (Item item : bankItemContainer.getItems()) {
                if (itemManager.getItemComposition(item.getId()).getName().equalsIgnoreCase(itemName) && item.getQuantity() >= minStackAmount) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean contains(int itemID, int minStackAmount) {
        if (isOpen()) {
            ItemContainer bankItemContainer = client.getItemContainer(InventoryID.BANK);
            final WidgetItem bankItem;
            if (bankItemContainer != null) {
                for (Item item : bankItemContainer.getItems()) {
                    if (item.getId() == itemID) {
                        return item.getQuantity() >= minStackAmount;
                    }
                }
            }
        }
        return false;
    }

    public Widget getBankItemWidget(int id) {
        if (!isOpen()) {
            return null;
        }

        WidgetItem bankItem = new BankItemQuery().idEquals(id).result(client).first();
        if (bankItem != null) {
            return bankItem.getWidget();
        } else {
            return null;
        }
    }

    //doesn't NPE
    public Widget getBankItemWidgetAnyOf(int... ids) {
        if (!isOpen()) {
            return null;
        }

        WidgetItem bankItem = new BankItemQuery().idEquals(ids).result(client).first();
        if (bankItem != null) {
            return bankItem.getWidget();
        } else {
            return null;
        }
    }

    public Widget getBankItemWidgetAnyOf(Collection<Integer> ids) {
        if (!isOpen() && !isDepositBoxOpen()) {
            return null;
        }

        WidgetItem bankItem = new BankItemQuery().idEquals(ids).result(client).first();
        if (bankItem != null) {
            return bankItem.getWidget();
        } else {
            return null;
        }
    }

    public void depositAll() {
        if (!isOpen() && !isDepositBoxOpen()) {
            return;
        }
        Widget t = client.getWidget(WidgetInfo.BANK_DEPOSIT_INVENTORY);
        sniper.cSnipe(new Sniper.TargetWidget(t), 1, 5000);
    }

    public void depositAllOfItem(WidgetItem item) {
        if (!isOpen() && !isDepositBoxOpen()) {
            return;
        }
        Sniper.TargetWidgetItem t = new Sniper.TargetWidgetItem(item);
        sniper.cSnipeMenu(t, "Deposit-All", 5000);
    }

    public void depositAllOfItem(int itemID) {
        if (!isOpen() && !isDepositBoxOpen()) {
            return;
        }
        depositAllOfItem(inventory.getWidgetItem(itemID));
    }

    public void depositOneOfItem(WidgetItem item) {
        if (!isOpen() && !isDepositBoxOpen() || item == null) {
            return;
        }
        Sniper.TargetWidgetItem t = new Sniper.TargetWidgetItem(item);
        sniper.cSnipe(t, 1, 5000);
    }

    public void depositOneOfItem(int itemID) {
        if (!isOpen() && !isDepositBoxOpen()) {
            return;
        }
        depositOneOfItem(inventory.getWidgetItem(itemID));
    }

    public void withdrawAllItem(Widget bankItemWidget) {
        scrollUntilContained(bankItemWidget);
        Sniper.TargetWidget t = new Sniper.TargetWidget(bankItemWidget);
        sniper.cSnipeMenu(t, "Withdraw-All", 5000);
    }

    final int PIXELS_PER_WHEELAMT = 45;  // Sniper

    public void scrollUntilContained(Widget bankItemWidget) {
        if (!isOpen()) {
            return;
        }
        Widget bankContainerWidget = client.getWidget(WidgetInfo.BANK_ITEM_CONTAINER);
        if (bankContainerWidget == null){
            return;
        }
        Rectangle bankContainerBox = sniper.canvasBox(bankContainerWidget);

        // Move in bank container
        if (!bankContainerBox.contains(client.getMouseCanvasPosition().getX(),
                                                      client.getMouseCanvasPosition().getY())) {
            Sniper.TargetWidget t = new Sniper.TargetWidget(client.getWidget(WidgetInfo.BANK_ITEM_CONTAINER));
            sniper.cSnipe(t, 0, 5000);
        }

        int timeoutMS = 3000;
        long to = System.currentTimeMillis() + timeoutMS;
        Rectangle getterBox = sniper.canvasBox(bankItemWidget);
        while (!bankContainerBox.contains(getterBox) && System.currentTimeMillis() < to) {
            double widgetTop = getterBox.getY();
            double widgetBottom = widgetTop + getterBox.getHeight();
            double bankBoxTop = bankContainerBox.getY();
            double bankBoxBottom = bankBoxTop + bankContainerBox.getHeight();
            int overshootAmt = ThreadLocalRandom.current().nextInt(0, 4); // Overshoot
            if (widgetTop < bankBoxTop) {
                double ydiff = bankBoxTop - widgetTop;
                int wheelAmt = -(int) ceil(ydiff / PIXELS_PER_WHEELAMT); // Scroll up
                if (wheelAmt < -1) {
                    wheelAmt -= overshootAmt;
                }
                sniper.cScroll(wheelAmt);
            } else if (widgetBottom > bankBoxBottom) {
                double ydiff = widgetBottom - bankBoxBottom;
                int wheelAmt = (int) ceil(ydiff / PIXELS_PER_WHEELAMT); // Scroll down
                if (wheelAmt > 1) {
                    wheelAmt += overshootAmt;
                }
                sniper.cScroll(wheelAmt);
            }
        }

    }

    public void withdrawAllItem(int bankItemID) {
        Widget item = getBankItemWidget(bankItemID);
        if (item != null) {
            withdrawAllItem(item);
        } else {
            log.debug("Withdraw all item not found.");
        }
    }

    public void withdrawItem(Widget bankItemWidget) {
        scrollUntilContained(bankItemWidget);
        Sniper.TargetWidget t = new Sniper.TargetWidget(bankItemWidget);
        sniper.cSnipe(t, 1, 5000);
    }

    public void withdrawItem(int bankItemID) {
        Widget item = getBankItemWidget(bankItemID);
        if (item != null) {
            withdrawItem(item);
        }
    }

    public void withdrawItemAmount(int bankItemID, int amount) {
        Widget item = getBankItemWidget(bankItemID);
        scrollUntilContained(item);
        Sniper.TargetWidget t = new Sniper.TargetWidget(item);
        String menuOption;
        switch (amount) {
            case 1:
                withdrawItem(bankItemID);
                return;
            case 5:
                menuOption = "Withdraw-5";
                break;
            case 10:
                menuOption = "Withdraw-10";
                break;
            default:
                menuOption = "Withdraw-X";
                break;
        }
        sniper.cSnipeMenu(t, menuOption, 5000);
//        int delayMS = Utils.unifInt(1200, 1800)
        int delayMS = Utils.unifInt(1000, 18000);
        sniper.cTypeDelated(Integer.toString(amount), delayMS);
    }
}

