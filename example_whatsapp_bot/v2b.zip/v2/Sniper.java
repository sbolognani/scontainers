package net.runelite.client.plugins.v2;

import com.google.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import naturalmouse.api.MouseMotion;
import naturalmouse.api.MouseMotionObserver;
import net.runelite.api.*;
import net.runelite.api.Point;
import net.runelite.api.coords.LocalPoint;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetItem;
import net.runelite.client.ui.ClientUI;

import javax.annotation.Nullable;
import javax.sound.sampled.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;

@Slf4j
public class Sniper implements MouseMotionObserver {

    @Inject
    Client client;

    @Inject
    private final V2Plugin plugin;

    @Inject
    ClientUI clientUI;

    @Inject
    public Eskedit eskedit;


    final int MENUWIDTH = 30;
    final int MENUHEIGHT = 15;
    final int MENUOFFSET = 19;

//    BufferedImage crosshair = ImageUtil.getResourceStreamFromClass(getClass(), "crosshair.png");
    Clip hitclip = null;
    AudioInputStream stream = null;

    Thread holdThread;

    ExecutorService control = Executors.newFixedThreadPool(1);

    ProtectedObject<Target> target = new ProtectedObject<>();
    int targetX = 0;
    int targetY = 0;

    public Sniper(V2Plugin plugin) {
        this.plugin = plugin;
        this.client = plugin.client;
        this.clientUI = plugin.clientUI;
        try {
            String path = System.getProperty("user.dir");
            path += "/cod.wav";
            this.stream = AudioSystem.getAudioInputStream(new File(path));
            DataLine.Info info;
            {
                assert stream != null;
                info = new DataLine.Info(Clip.class, stream.getFormat());
            }
            this.hitclip = (Clip) AudioSystem.getLine(info);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }

        try {
            this.eskedit = new Eskedit();
        } catch (AWTException e) {
            e.printStackTrace();
            return;
        }
        hitmarkSound();
    }

    public void cSnipe(Target t, int buttonID, int timeoutMS) {
        this.control.submit(() -> snipe(t, buttonID, timeoutMS));
    }

    public void cSnipeMenu(Target t, String menuOption, int timeoutMS) {
        this.control.submit(() -> snipeMenu(t, menuOption, timeoutMS));
    }

    public Boolean snipe(Target t, int buttonID, int timeoutMS) {
        if (t == null) {
            log.error("Target null");
            return false;
        }

        this.target.set(t);

        long deadline = System.currentTimeMillis() + 200;

        while (t.getHull() == null) {
            synchronized (this) {
                try {
                    wait(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            if (System.currentTimeMillis() > deadline) {
                log.error("Timeout! What is your framerate?");
                return false;
            }
        }

        if ((t instanceof TargetActor || t instanceof TargetTile)) {
            rotateAndZoom(t);
        }

        deadline = System.currentTimeMillis() + timeoutMS;

        while (System.currentTimeMillis() < deadline) {
            Point mousePosition = client.getMouseCanvasPosition();
            if (!t.getHull().contains(mousePosition.getX(), mousePosition.getY())) {
                Point clickPoint = t.getClickPoint();
                if (clickPoint == null) {
                    log.error("Could not get clickPoint");
                    return false;
                }
                MouseMotion motion = getMotion(clickPoint);
                this.targetX = clickPoint.getX();
                this.targetY = clickPoint.getY();
                moveMotion(motion);
            } else {
//                log.info("T" + t.getHull().getBounds().toString() + " contains " + mousePosition.toString());
                click(buttonID);
                return true;
            }
        }
        this.target.set(null);
        log.warn("Sniper too slow!");
        return false; // Timeout
    }

    public Boolean snipeMenu(Target t, String menuOption, int timeoutMS) {
        snipe(t, 3, timeoutMS);
        Utils.sleeprand(20, 60);
        Point openedPos = client.getMouseCanvasPosition();

        long to = System.currentTimeMillis() + timeoutMS;
        while (!client.isMenuOpen()) {
            Utils.sleep(20);
            if (System.currentTimeMillis() > to) {
                log.error("No open Menu within timeout");
                return false;
            }
        }
        MenuEntry[] menuEntries = client.getMenuEntries();
        boolean found = false;
        int pos = 0;
        for (int i = menuEntries.length - 1; i >= 0; i--) {
            String option = menuEntries[i].getOption();
            if (option.equals(menuOption)) {
                found = true;
                // MenuEntry[] newMenuEntries = new MenuEntry[]{menuEntries[i]};
                // client.setMenuEntries(newMenuEntries);
                break;
            }
            pos++;
        }
        if (!found) {
            log.error("Menu does not have this option");
            return false;
        }
        Rectangle s = new Rectangle(
                openedPos.getX() - MENUWIDTH,
                (openedPos.getY() + MENUOFFSET + (pos * MENUHEIGHT)), // TODO
                MENUWIDTH * 2,
                MENUHEIGHT
        );
        snipe(new TargetCustom(s), 1, 2000);
        return true;
    }

    public void rotateAndZoom(Target t) {
        rotateInRange(t);
        zoomUntilContained(t);
    }

    public void rotateInRange(Target t) {
        int acceptMin = 45;
        int acceptMax = 315;
        int angle = t.getAngle();

        while (!((angle < acceptMin) || (angle > acceptMax))) {
            int holdMS = Utils.unifInt(50, 200);
            if (angle < 180) {
                eskedit.holdKey(KeyEvent.VK_LEFT, holdMS);
            }
            if (angle > 180) {
                eskedit.holdKey(KeyEvent.VK_RIGHT, holdMS);

            }
            Utils.sleep(holdMS);
            Utils.sleeprand(10, 50);
            angle = t.getAngle();
        }
        log.info("Rotated");
    }

    public final int MIN_SCALE = 181;
    public int CHILL_SCALE = 250;

    public void cScroll(int wheelAmt) {
        this.control.submit(() -> scroll(wheelAmt));
    }

    public Boolean zoomUntilContained(Target t) {
        if (plugin.viewPortBounds == null) {
            log.info("VPB NULL");
            return false;
        }
        Point mpos = client.getMouseCanvasPosition();
        if (!plugin.viewPortBounds.contains(mpos.getX(), mpos.getY())) {
            snipe(new TargetCustom(plugin.viewPortBounds), 0, 2000);
        }
        this.target.set(t);
        synchronized (this) {
            try {
                wait(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        while (!plugin.viewPortBounds.contains(t.getHull().getBounds())) {
            if (client.getScale() < CHILL_SCALE) {
                log.warn("Target not in viewport after zooming to CHILL_SCALE");
                return false;
            }
            scroll(2);
            synchronized (this) {
                try {
                    wait(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        log.info("scrolled");
        return true;
    }

    public void scroll(int wheelAmt) {
        eskedit.mouseWheel(wheelAmt);
    }

    public void holdShift() {
        log.info("Shifting");
        if (holdThread != null) {
            log.error("Shifter not dead yet?");
            return;
        }
        holdThread = eskedit.holdKeyIndefinitely(KeyEvent.VK_SHIFT);
        Utils.sleep(200);
        log.info("shifted");
    }

    public void releaseShift() {
        log.info("Releasing");
        holdThread.interrupt();
        eskedit.keyRelease(KeyEvent.VK_SHIFT);
        log.info("Released");
        holdThread = null;
    }

    public int relHorizontal(int x) {
        return x + ClientUI.frame.getX() + clientUI.getCanvasOffset().getX();
    }

    public int relVertical(int y) {
        return y + ClientUI.frame.getY() + clientUI.getCanvasOffset().getY();
    }

    @Override
    public Boolean observe(int xPos, int yPos) {
        return target.get().getHull().contains(targetX, targetY);
    };

    private Point getxDestyDest(Point clickPoint) throws IllegalStateException {
        return new Point(relHorizontal(clickPoint.getX()), relVertical(clickPoint.getY()));
    }

    private MouseMotion getMotion(Point clickPoint) throws IllegalStateException {
        Point dest = getxDestyDest(clickPoint);
        return eskedit.currentMouseMotionFactory.build(dest.getX(), dest.getY());
    }

    public void moveMotion(MouseMotion motion) {
        try {
            motion.move(this);
        } catch (InterruptedException e) {
            log.error("Interrupted!");
            e.printStackTrace();
        }
    }

    public void cType(String text) {
        this.control.submit(() -> this.eskedit.type(text));
    }

    public void cTypeDelated(String text, int delayMS) {
        this.control.submit(() -> this.typeDelayed(text, delayMS));

    }
    public void typeDelayed(String text, int delayMS) {
        Utils.sleep(delayMS);
        this.eskedit.type(text);
    }

    public void click(int buttonID) {
        if (buttonID != 0) {
            eskedit.mousePressAndRelease(buttonID);
        }
        hitmarkSound();
        this.target.set(null);
        log.info("Sniped");
    }

    public interface Target {
        Shape update();

        ProtectedObject<Shape> hull = new ProtectedObject<>();

        default void setHull() {
            Shape s = update();
            hull.set(s);
        }

        default Shape getHull() {
            return hull.get();
        }

        @Nullable
        default Point getClickPoint() {
            Shape s = getHull();
            while (s == null) {  // Does not happen?
                Utils.sleep(10);
                s = getHull();
            }
            return gaussInShape(s);
        }

        default Integer getAngle() {
            // In degrees, 0 and 360 NORTH, 90 degrees EAST etc.
            Point targetPt = getClickPoint();
            if (targetPt == null) {
                return null;
            }
            double theta = Math.atan2(targetPt.getY() - V2Plugin.BOTTOM_CENTER.getY(), targetPt.getX() - V2Plugin.BOTTOM_CENTER.getX());
            theta += Math.PI / 2.0;
            double angle = Math.toDegrees(theta);
            if (angle < 0) {
                angle += 360;
            }
            return (int) angle;
        }
        default Point gaussInShape(Shape s) {
            return Sniper.gaussInShape(s);
        }
    }

    public static Point gaussInShape(Shape s) {
        Rectangle r = s.getBounds();
        double x = 1 / (1 + Math.exp(-ThreadLocalRandom.current().nextGaussian()));
        double y = 1 / (1 + Math.exp(-ThreadLocalRandom.current().nextGaussian()));
        x = (r.getX() + r.getWidth() * x);
        y = (r.getY() + r.getHeight() * y);
        if (!s.contains(x, y)) {
            return gaussInShape(s);  // TODO how many calls?
        } else {
            return new Point((int) x, (int) y);
        }
    }


    public static class TargetActor implements Target {
        Actor actor;

        public TargetActor(Actor actor) {
            this.actor = actor;
        }

        @Override
        public Shape update() {
            return actor.getConvexHull();
        }
    }

    public static class TargetWidget implements Target {
        Widget widget;

        public TargetWidget(Widget widget) {
            this.widget = widget;
        }

        @Override
        public Shape update() {
            return new Rectangle(
                    widget.getCanvasLocation().getX(),
                    widget.getCanvasLocation().getY(),
                    widget.getWidth(),
                    widget.getHeight()
            );
        }
    }

    public Rectangle canvasBox(Widget w) {
        Point canvasLocation = w.getCanvasLocation();
        return new Rectangle(
                canvasLocation.getX(),
                canvasLocation.getY(),
                w.getWidth(),
                w.getHeight()
        );
    }

    public static class TargetWidgetItem implements Target {
        WidgetItem widgetItem;

        public TargetWidgetItem(WidgetItem widgetItem) {
            this.widgetItem = widgetItem;
        }

        @Override
        public Shape update() {
            return widgetItem.getCanvasBounds();
        }
    }

    public static class TargetObject implements Target {
        GameObject gameObject;

        public TargetObject(GameObject gameObject) {
            this.gameObject = gameObject;
        }

        @Override
        public Shape update() {
            return gameObject.getConvexHull();
        }
    }

    public static class TargetCustom implements Target {
        Shape shape;

        public TargetCustom(Shape shape) {
            this.shape = shape;
        }

        @Override
        public Shape update() {
            return this.shape;
        }
    }

    public class TargetTile implements Target {
        Tile tile;

        public TargetTile(Tile tile) {
            this.tile = tile;
        }

        @Override
        public Shape update() {
            LocalPoint lp = LocalPoint.fromWorld(client, tile.getWorldLocation());
            if (lp == null) {
                return null;
            }
            return Perspective.getCanvasTilePoly(client, lp);
        }
    }

    public void cTypeTabKey(TabKey tabKey) {
        this.control.submit(() -> eskedit.typeKeycode(tabKey.keycode));
    }

    public enum TabKey {

        COMBAT(KeyEvent.VK_F1),
        EXP(KeyEvent.VK_F2),
        QUESTS(KeyEvent.VK_F3),
        INVENTORY(KeyEvent.VK_ESCAPE),
        EQUIPMENT(KeyEvent.VK_F4),
        PRAYER(KeyEvent.VK_F5),
        SPELLBOOK(KeyEvent.VK_F6),
        CLAN(KeyEvent.VK_F7),
        FRIENDS(KeyEvent.VK_F8),
        MANAGEMENT(KeyEvent.VK_F9),
        LOGOUT(999),
        SETTINGS(KeyEvent.VK_F10),
        EMOTES(KeyEvent.VK_F11),
        MUSIC(KeyEvent.VK_F12);

        public final int keycode;

        TabKey(int keycode) {
            this.keycode = keycode;
        }
    }

    public void hitmarkSound() {
        if (stream == null || hitclip == null) {
            return;
        }
        try {
            if (hitclip.isOpen()) {
                hitclip.stop();
                hitclip.setFramePosition(0);
            } else {
                hitclip.open(stream);
            }
            hitclip.start();
        } catch (IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

}
