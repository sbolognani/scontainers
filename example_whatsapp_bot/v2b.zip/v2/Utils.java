package net.runelite.client.plugins.v2;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

@Slf4j
public class Utils {

    protected static final java.util.Random random = new java.util.Random();


    public static void sleeprand(int minms, int maxms) {
        int wait_before = ThreadLocalRandom.current().nextInt(minms, maxms);
        try {
            TimeUnit.MILLISECONDS.sleep(wait_before);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void sleep(int ms) {
        try {
            TimeUnit.MILLISECONDS.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static int unifInt(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }

//    public static int
    //Ganom's function, generates a random number allowing for curve and weight
    public long randomDelay(boolean weightedDistribution, int min, int max, int deviation, int target)
    {
        if (weightedDistribution)
        {
            /* generate a gaussian random (average at 0.0, std dev of 1.0)
             * take the absolute value of it (if we don't, every negative value will be clamped at the minimum value)
             * get the log base e of it to make it shifted towards the right side
             * invert it to shift the distribution to the other end
             * clamp it to min max, any values outside of range are set to min or max */
            return (long) clamp((-Math.log(Math.abs(random.nextGaussian()))) * deviation + target, min, max);
        }
        else
        {
            /* generate a normal even distribution random */
            return (long) clamp(Math.round(random.nextGaussian() * deviation + target), min, max);
        }
    }

    private double clamp(double val, int min, int max)
    {
        return Math.max(min, Math.min(max, val));
    }

}

