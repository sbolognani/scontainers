package net.runelite.client.plugins.v2;

import net.runelite.client.config.Config;
import net.runelite.client.config.ConfigGroup;
import net.runelite.client.config.ConfigItem;

@ConfigGroup("v2")
public interface V2Config extends Config {
    @ConfigItem(
            keyName = "gibsMagic",
            name = "Gibs magic xp",
            description = "Gibs magic xp",
            position = 1
    )
    default boolean gibsMagic() { return false; }
}