package net.runelite.client.plugins.v2;

import com.google.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.Point;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.ui.overlay.Overlay;
import net.runelite.client.ui.overlay.OverlayLayer;
import net.runelite.client.ui.overlay.OverlayPosition;
import net.runelite.client.ui.overlay.OverlayPriority;

import java.awt.*;

@Slf4j
public class V2Overlay extends Overlay {


    private final V2Plugin plugin;
    private Client client;

    @Inject
    private V2Overlay(final Client client, final V2Plugin plugin) {
        setPosition(OverlayPosition.DYNAMIC);
        setLayer(OverlayLayer.ALWAYS_ON_TOP);
        setPriority(OverlayPriority.HIGH);
        this.client = client;
        this.plugin = plugin;
    }

    @Override
    public Dimension render(Graphics2D graphics) {

        if (plugin.sniper != null) {
            Sniper.Target t = plugin.sniper.target.get();
            if (t != null) {
                t.setHull();
                Shape s = t.getHull();
                if (s != null) {
                    graphics.draw(s);
                }
            }
            synchronized (plugin.sniper) {
                plugin.sniper.notifyAll();
            }
        }
        return getBounds().getSize();
    }
}
