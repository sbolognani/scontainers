package net.runelite.client.plugins.v2;

import com.google.inject.Inject;
import com.google.inject.Provides;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Client;
import net.runelite.api.ItemID;
import net.runelite.api.NPC;
import net.runelite.api.Point;
import net.runelite.api.events.CanvasSizeChanged;
import net.runelite.api.events.ChatMessage;
import net.runelite.api.events.ResizeableChanged;
import net.runelite.api.queries.NPCQuery;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.ClientUI;
import net.runelite.client.ui.overlay.OverlayManager;

import javax.annotation.Nullable;
import java.awt.*;

@PluginDescriptor(
        name = "V2",
        description = "Voor 3BB1",
        tags = {"Ze is lief"}
)
@Slf4j
public class V2Plugin extends Plugin {

    @Inject
    Client client;

    @Inject
    ClientUI clientUI;

    @Inject
    OverlayManager overlayManager;

    @Inject
    V2Config v2Config;

    @Inject
    BankUtils bankUtils;

    @Inject
    public V2Overlay overlay;

    public Sniper sniper;

    @Provides
    V2Config provideConfig(ConfigManager configManager) {
        return configManager.getConfig(V2Config.class);
    }

    public V2Plugin() {
        log.info("19-11-2020");
    }

    public static Point BOTTOM_CENTER = new Point(0, 0);

    @Override
    protected void startUp() throws Exception {

        this.sniper = new Sniper(this);

        if (clientUI == null) {
            return;
        }
        overlayManager.add(overlay);
    }

    @Subscribe
    public void onChatMessage(ChatMessage event) {
        String message = event.getMessage();
        if (message.contains("snipa")) {
            NPC banker = findNearestNpc("Banker");
            sniper.cSnipe(new Sniper.TargetActor(banker), 1, 3000);
        }
        if (message.contains("voor wie")) {
            sniper.cType("Voor mijn allerliefste");
        }

        if (message.contains("gettem")) {
            bankUtils.withdrawItem(ItemID.ARDOUGNE_CLOAK_2);
        }
    }

    @Nullable
    public NPC findNearestNpc(String... names)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new NPCQuery()
                .nameContains(names)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    Rectangle viewPortBounds = new Rectangle(0, 0, 1000, 1000);
    private void setViewPortBounds() {
        log.info("setting viewPortBounds");
        if (client.isResized()) {
            Widget w = client.getWidget(WidgetInfo.RESIZABLE_VIEWPORT_BOTTOM_LINE);
            if (w != null) {
                viewPortBounds = w.getBounds();
            }
        } else {
            Widget w = client.getWidget(WidgetInfo.FIXED_VIEWPORT);
            if (w != null) {
                viewPortBounds = w.getBounds();
            }
        }
        double cx = viewPortBounds.getCenterX();
        BOTTOM_CENTER = new Point((int) cx, (int) (viewPortBounds.getY() + viewPortBounds.getHeight()));
    }

    @Subscribe
    public void onResizeableChanged(ResizeableChanged event) {
        log.info("ResizableChanged event");
        setViewPortBounds();
    }

    @Subscribe
    public void onCanvasSizeChanged(CanvasSizeChanged event) {
        log.info("CanvasSizeChanged event");
        setViewPortBounds();
    }


}
