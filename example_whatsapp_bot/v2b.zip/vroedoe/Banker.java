package net.runelite.client.plugins.vroedoe;

import net.runelite.api.Client;
import net.runelite.api.widgets.Widget;
import com.google.common.collect.Sets;
import java.util.concurrent.TimeUnit;
import lombok.extern.slf4j.Slf4j;
import net.runelite.client.plugins.Plugin;

import java.awt.event.KeyEvent;
import java.util.Comparator;
import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

@Slf4j
@Singleton
public class Banker {

    @Inject
    private final VroedoePlugin plugin;

    @Inject
    Client client;

    @Inject
    private final Sniper sniper;
    public Gear fabulous;
    public Inventory inv;
    String BANKPIN = "1708";

//    HashMap<Integer, Inventory.Item> withdrawalItems = null;

    public Banker(VroedoePlugin plugin)
    {
        this.plugin = plugin;

        assert plugin.sniper != null;
        assert plugin.inv != null;
        assert plugin.fabulous != null;
        this.inv = plugin.inv;
        this.sniper = plugin.sniper;
        this.fabulous = plugin.fabulous;
    }

    public void enterBankPin() {
        System.out.println("Got here 12345");
        if (plugin.BANK_PIN_CONTAINER == null) {
            System.out.println("Trying to enter bank pin but BankPinWidget not active");
            return;
        }
        Utils.sleeprand(200, 800);
        sniper.type(BANKPIN);
    }

    public Widget findBankerAndBank() {
        System.out.println("Finding banker");

        long timeoutMS = 10000;
        long t = System.currentTimeMillis() + timeoutMS;
        while (!plugin.nearestNPCs.containsKey("Banker")) {
            Utils.sleep(50);
            if (System.currentTimeMillis() > t) {
                log.error("Timeout");
                plugin.watchingNPCs.remove("Banker");
                return null;
            }
        }
        Sniper.TargetActor target = plugin.nearestNPCs.get("Banker");
        Boolean clicked = sniper.snipeMenu(target, "Bank", 5000);
        if (clicked == null) {
            log.error("Did not click...");
            plugin.watchingNPCs.remove("Banker");
            return null;
        }

        t = System.currentTimeMillis() + timeoutMS;
        boolean requirePin = true;
        while (System.currentTimeMillis() < t) {
            if (plugin.BANK_PIN_CONTAINER != null && requirePin) {
                enterBankPin();
                requirePin = false;
            }
            if (plugin.BANK_ITEM_CONTAINER == null) {
                Utils.sleep(50);
            } else {
                break;
            }
        }
        plugin.watchingNPCs.remove("Banker");
        return plugin.BANK_ITEM_CONTAINER;
    }


    public void depositInventory() {
        long timeoutMS = 8000;
        long t = System.currentTimeMillis() + timeoutMS;
        while (plugin.BANK_DEPOSIT_INVENTORY == null) {
            Utils.sleep(50);
            if (System.currentTimeMillis() > t) {
                log.error("Timeout!");
                return;
            }
        }
        Sniper.Target target = new Sniper.TargetWidget(plugin.BANK_DEPOSIT_INVENTORY);
        sniper.snipe(target, 1, 10000);
        Utils.sleeprand(50, 100);
        inv.updateInventory();
        System.out.println("Carrying: " + inv.carryingItems.size());
    }

    public Boolean withdrawBankItems() {
        System.out.println("Withdrawing bank items");
        if (inv == null) {
            System.out.println("inv null");
        }

        plugin.equipAll();
        System.out.println("Equipped all");

        inv.printers();
        inv.updateInventory();

        boolean depositing = inv.redundantItems.size() > 0;
        boolean withdrawing = inv.missingItems.size() > 0;
        if (!depositing && !withdrawing) {
            System.out.println("No need to bank");
            return true;
        }

        int tries = 3;
        while (!plugin.nav.inDestination(Destinations.ARDY_NORTH_BANK)
               && tries > 0) {
            plugin.nav.wonkyWalk(Destinations.ARDY_NORTH_BANK);
            tries--;
        }

        Widget bankItemContainer = findBankerAndBank();
        Utils.sleeprand(200, 600);//

        if (bankItemContainer == null) {
            System.out.println("No bank container!");
            return false;
        }

        HashMap<Integer, Widget> matchingWidgets = new HashMap<>();
        ArrayList<Widget> matchingWidgetsArray = new ArrayList<>();

        if (depositing) {
            System.out.println("Depositing " + inv.redundantItems.keySet());
            depositInventory();
            inv.updateInventory();
        }

//        for (Inventory.Item depositingItem : Lists.newArrayList(inv.redundantItems.values())) {
//            System.out.println("Depositing item id " + depositingItem.id);
//            WidgetItem depositingWidgetItem = inv.getWidgetByItemID(depositingItem.id, true, 0);
//            if (depositingWidgetItem == null) {
//                System.out.println("TODO what is this");
//                continue;
//            }
//            Sniper.TargetWidgetItem target = new Sniper.TargetWidgetItem(depositingWidgetItem);
//            System.out.println(target.widgetItem.getId());
//            switch (depositingItem.depositMethod) {
//                case "LEFT_CLICK":
//                    sniper.snipe(target, 1, 10000);
//                    break;
//                case "Deposit-All":
//                    sniper.snipe(target, 3, 10000);
//                    sniper.snipeMenuOption(depositingItem.depositMethod, 1000);
//                    break;
//                case "Deposit-X":
//                    sniper.snipe(target, 3, 10000);
//                    sniper.snipeMenuOption(depositingItem.depositMethod, 10000);
//                    Utils.sleeprand(800, 1600);
//                    sniper.type(
//                            depositingItem.amount + "\n");
//                    break;
//            }
//        }

        System.out.println("Finished depositing");
//        Widget bankTitle = plugin.getWidget(WidgetInfo.BANK_TITLE_BAR);
//        bankTitle.setText("The Bank of Cancer");
        // Dont call too fast? TODO
        plugin.sleeprand(300, 400);
        inv.updateInventory();
        System.out.println("Children in bank: " + bankItemContainer.getDynamicChildren().length);

        if (!withdrawing) {
            System.out.println("No items being requested");
            // TODO
            sniper.typeKeycode(KeyEvent.VK_ESCAPE);
            Utils.sleeprand(150, 300);
            plugin.equipAll();
            return true;
        }

        for (Widget w : bankItemContainer.getDynamicChildren()) {
            if (w.getCanvasLocation() == null) {
                System.out.println("TODO what is this");
                continue;
            }
            int id = w.getItemId();
            if (inv.missingItems.containsKey(id)) {
                System.out.println("Found " + id);
                int requestedAmount = inv.missingItems.get(id).amount;
                if (w.getItemQuantity() >= requestedAmount) {
                    matchingWidgets.put(id, w);
                    matchingWidgetsArray.add(w);
                }
            }
        }
        Set<Integer> missingIds = Sets.difference(inv.missingItems.keySet(), matchingWidgets.keySet());
        if (missingIds.size() != 0) {
            log.warn("Missing items: " + missingIds);
            return false;
        }

        System.out.println("Found " + matchingWidgets.size());

        // Prep mouse for scroll, // TODO depends on currentMousePos

        Comparator ascYLocation = new Comparator<Widget>() {
            @Override
            public int compare(Widget w1, Widget w2) {
                return Integer.compare(w1.getCanvasLocation().getY(), w2.getCanvasLocation().getY());
            }
        };

        matchingWidgetsArray.sort(ascYLocation);
        for (Widget w : matchingWidgetsArray) {
            plugin.scrollWhileWidgetNotContained(w, bankItemContainer);
            Sniper.TargetWidget target = new Sniper.TargetWidget(w);
            Inventory.Item gameItem = inv.missingItems.get(w.getItemId());
            System.out.println("Gettin " + gameItem.id);
            if (gameItem.withdrawalMethod.equals("LEFT_CLICK")) {
                sniper.snipe(target, 1, 10000);
            } else {
                sniper.snipeMenu(target, gameItem.withdrawalMethod, 10000);
                if (gameItem.withdrawalMethod.equals("Withdraw-X")) {
                    Utils.sleeprand(1200, 1800);
                    sniper.type(Integer.toString(gameItem.amount) + "\n");
                }
            }
        }

        boolean missing = true;
        for (int i = 0; i < 20; i++) {
            if (inv.hasMissingItems()) {
                inv.updateInventory();
                System.out.println("Missing" + inv.missingItems.keySet());
                Utils.sleep(200);
            } else {
                missing = false;
                break;
            }
        }
        sniper.typeKeycode(KeyEvent.VK_ESCAPE);
        Utils.sleeprand(150, 300);
        plugin.equip(inv.getCarryingToEquipIDs());

        if (missing) {
            return null;
        }

        sniper.typeKeycode(KeyEvent.VK_ESCAPE);
        Utils.sleeprand(150, 300);
        return true;
    }

    public void withdrawEquipment() {
        // TODO
    }



}
