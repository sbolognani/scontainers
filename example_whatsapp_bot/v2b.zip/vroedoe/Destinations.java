package net.runelite.client.plugins.vroedoe;

import joptsimple.ValueConversionException;
import net.runelite.api.coords.WorldPoint;

public enum Destinations {
    // The spanned areas may only contain 'reachable' WorldPoints

    ARDY_NORTH_BANK(new WorldPoint(2613, 3332, 0),
            new WorldPoint(2620, 3333, 0)),

    ARDY_MASTER_FARMER(new WorldPoint(2635, 3358, 0),
            new WorldPoint(2640, 3365, 0)),

    ARDY_NORTH_PATCH(new WorldPoint(2672, 3373, 0),
            new WorldPoint(2676, 3380, 0)
    );

    WorldPoint southWest;
    WorldPoint northEast;
    int z;

    Destinations(WorldPoint southWest, WorldPoint northEast) {
        assert southWest.getPlane() == northEast.getPlane();
        this.southWest = southWest;
        this.northEast = northEast;
        this.z = southWest.getPlane();
    }
}
