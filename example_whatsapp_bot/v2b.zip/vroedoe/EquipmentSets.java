package net.runelite.client.plugins.vroedoe;

import net.runelite.api.ItemID;
import org.apache.commons.lang3.tuple.Pair;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public enum EquipmentSets {

    FARM_RUN(Arrays.asList(
            Pair.of(ItemID.MAGIC_SECATEURS,1),
            Pair.of(ItemID.EXPLORERS_RING_2, 1),
            Pair.of(ItemID.ARDOUGNE_CLOAK_2, 1),
            Pair.of(ItemID.CHRONICLE, 1)
//            Pair.of(ItemID.SKILLS_NECKLACE4, 1)
    )),

    THIEVER(Arrays.asList(
//            Pair.of(ItemID.DODGY_NECKLACE, 1),
            Pair.of(ItemID.ARDOUGNE_CLOAK_2, 1)
//            Pair.of(ItemID.ROGUE_MASK, 1),
//            Pair.of(ItemID.ROGUE_TOP, 1),
//            Pair.of(ItemID.ROGUE_TROUSERS, 1),
//            Pair.of(ItemID.ROGUE_BOOTS, 1),
//            Pair.of(ItemID.ROGUE_GLOVES, 1)
//            Pair.of(ItemID.SKILLS_NECKLACE4, 1)
    ));
    
    HashMap<Integer, Inventory.Item> items;

    EquipmentSets(List<Pair<Integer, Integer>> id_amount_list) {
        this.items = new HashMap<>();
        for (Pair<Integer, Integer> id_amount : id_amount_list) {
            Integer id = id_amount.getLeft();
            Integer amount = id_amount.getRight();
            Inventory.Item item = new Inventory.Item(id, amount, false);
            item.equip = true;
            items.put(id, item);
        }
    }
}
