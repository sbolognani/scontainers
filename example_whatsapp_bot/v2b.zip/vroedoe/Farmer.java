package net.runelite.client.plugins.vroedoe;

import lombok.extern.slf4j.Slf4j;
import net.runelite.api.ItemID;
import net.runelite.api.Skill;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

@Slf4j
public class Farmer extends Shell {

    public Farmer(VroedoePlugin plugin) {
        super(plugin);
    }

    public static class ObjectIDs {
        public final int HERB_PATCH = 8152;
        public final int ALLOTMENT_NORTH_PATCH = 8554;
        public final int ALLOTMENT_SOUTH_PATCH = 8555;
        public final int FLOWER_PATCH = 7849;
        public final int COMPOST_BIN = 7839;
    }

    public enum TreeRuns {
        LUMBRIDGE(true, ItemSets.LUMBRIDGE_TELEPORT),
        VARROCK(true, ItemSets.VARROCK_TELEPORT),
        FALADOR_PARK(true, ItemSets.FALADOR_TELEPORT),
        TAVERLY(true, ItemSets.TAVERLY_POD_BALLOON),
        TREE_GNOME_STRONGHOLD(true, ItemSets.EMPTY_SET),
        FARMING_GUILD(false, ItemSets.EMPTY_SET);

        public final boolean included;
        public final ItemSets transportationItems;

        TreeRuns(boolean included, ItemSets transportationItems) {
            this.included = included;
            this.transportationItems = transportationItems;
        }
    }

    public enum BushRuns {

        CHAMPIONS_GUILD(true, ItemSets.EMPTY_SET),
        RIMMINGTON(false, ItemSets.EMPTY_SET),
        ARDOUGNE(false, ItemSets.EMPTY_SET),
        ETCETERIA(false, ItemSets.EMPTY_SET),
        FARMING_GUILD(false, ItemSets.EMPTY_SET);

        public final boolean included;
        public final ItemSets transportationItems;

        BushRuns(boolean included, ItemSets transportationItems) {
            this.included = included;
            this.transportationItems = transportationItems;
        }
    }

    public int selectBushSeed(int currentLevel) {
        if (currentLevel < 10) {
            System.out.println("Level too low for bushes!");
            return 0;
        } else if (currentLevel < 22) {
            return ItemID.REDBERRY_SEED;
        } else if (currentLevel < 36) {
            return ItemID.CADAVABERRY_SEED;
        } else if (currentLevel < 48) {
            return ItemID.DWELLBERRY_SEED;
        } else if (currentLevel < 59) {
            return ItemID.JANGERBERRY_SEED;
        } else if (currentLevel < 70) {
            return ItemID.WHITEBERRY_SEED;
        } else {
            return ItemID.POISON_IVY_SEED;
        }
    }

    public int selectHerbSeed(int currentLevel, boolean maxProfit, boolean highestPossible) {

        if (maxProfit) {
            return ItemID.RANARR_SEED;
        } else if (highestPossible) {
            if (currentLevel < 9) {
                System.out.println("Level too low for herbs!");
                return 0;
            } else if (currentLevel < 14) {
                return ItemID.GUAM_SEED;
            } else if (currentLevel < 19) {
                return ItemID.MARRENTILL_SEED;
            } else if (currentLevel < 26) {
                return ItemID.TARROMIN_SEED;
            } else if (currentLevel < 32) {
                return ItemID.HARRALANDER_SEED;
            } else if (currentLevel < 38) {
                return ItemID.RANARR_SEED;
            } else if (currentLevel < 44) {
                return ItemID.TOADFLAX_SEED;
            } else if (currentLevel < 50) {
                return ItemID.IRIT_SEED;
            } else if (currentLevel < 56) {
                return ItemID.AVANTOE_SEED;
            } else if (currentLevel < 62) {
                return ItemID.KWUARM_SEED;
            } else if (currentLevel < 67) {
                return ItemID.SNAPDRAGON_SEED;
            } else if (currentLevel < 73) {
                return ItemID.CADANTINE_SEED;
            } else if (currentLevel < 79) {
                return ItemID.LANTADYME_SEED;
            } else if (currentLevel < 85) {
                return ItemID.DWARF_WEED_SEED;
            } else {
                return ItemID.TORSTOL_SEED;
            }
        } else {
            return 0;
        }
    }

    public int selectAllotmentSeed(int currentLevel) {
        if (currentLevel < 5) {
            return ItemID.POTATO_SEED;
        } else if (currentLevel < 7) {
            return ItemID.ONION_SEED;
        } else if (currentLevel < 12) {
            return ItemID.CABBAGE_SEED;
        } else if (currentLevel < 20) {
            return ItemID.TOMATO_SEED;
        } else if (currentLevel < 31) {
            return ItemID.SWEETCORN_SEED;
        } else if (currentLevel < 47) {
            return ItemID.STRAWBERRY_SEED;
        } else if (currentLevel < 61) {
            return ItemID.WATERMELON_SEED;
        } else {
            return ItemID.SNAPE_GRASS_SEED;
        }
    }

    public int selectFlowerSeed(int currentLevel, boolean nasturtium) {
        if (nasturtium) {
            return ItemID.NASTURTIUM_SEED;
        }
        if (currentLevel < 2) {
            System.out.println("Level too low for flower patches");
            return 0;
        } else if (currentLevel < 11) {
            return ItemID.MARIGOLD_SEED;
        } else if (currentLevel < 24) {
            return ItemID.ROSEMARY_SEED;
        } else if (currentLevel < 25) {
            return ItemID.NASTURTIUM_SEED;
        } else if (currentLevel < 26) {
            return ItemID.WOAD_SEED;
        } else if (currentLevel < 58) {
            return ItemID.LIMPWURT_SEED;
        } else {
            return ItemID.WHITE_LILY_SEED;
        }
    }

    public int selectHops(int currentLevel, boolean maxProfit) {
        return ItemID.YANILLIAN_SEED;
    }

    boolean prifddinas = false;
    boolean morytania = false;
    boolean hosidius = false;
    boolean catherby = true;
    boolean harmony = false;
    boolean ardougne = true;
    boolean falador = true;
    boolean guild = false;
    boolean weiss = false;
    boolean troll = true;

    private void setRequestedInventory(int currentLevel,
                                           boolean herbs,
                                           boolean flowers,
                                           boolean allotments,
                                           boolean bushes,
                                           boolean trees,
                                           boolean protect) {

        HashMap<Integer, Inventory.Item> requestedItems = new HashMap<>(EquipmentSets.FARM_RUN.items);

        int herbSeed = selectHerbSeed(currentLevel, false, true);
        int flowerSeed = selectFlowerSeed(currentLevel, true);
        int allotmentSeed = selectAllotmentSeed(currentLevel);
        int bushSeed = selectBushSeed(currentLevel);

        int herbSeedAmount = 0;
        int flowerSeedAmount = 0;
        int allotmentSeedAmount = 0;

        if (catherby) {
            herbSeedAmount += 1;
            flowerSeedAmount += 1;
            allotmentSeedAmount += 6;
        }
        if (falador) {
            herbSeedAmount += 1;
            flowerSeedAmount += 1;
            allotmentSeedAmount += 6;
        }

        if (ardougne) {
            herbSeedAmount += 1;
            flowerSeedAmount += 1;
            allotmentSeedAmount += 6;
        }

        if (herbs) {
            requestedItems.put(herbSeed, new Inventory.Item(herbSeed, herbSeedAmount, false));
        }
        if (flowers) {
            requestedItems.put(flowerSeed, new Inventory.Item(flowerSeed, flowerSeedAmount, false));
        }
        if (allotments) {
            requestedItems.put(allotmentSeed, new Inventory.Item(allotmentSeed, allotmentSeedAmount, false));
        }

    plugin.inv.addRequestedItems(requestedItems);
    }

    public void allotment() {
        plugin.watchingNPCs.put("Tool Leprechaun", "Exchange");

        // Assert seeds
        // Assert inventory space
        // Find Gnome
//        plugin.client.getWidget(WidgetInfo)
        Widget w = plugin.client.getWidget(126, 0);
        plugin.drawer = w.getBounds();
    }

    // 125 (child of 548.23
    // 125.2
    // 8 rake
    // 9 seed dibber
    // 10 spade
    // 11 secateurs
    // 12 watering can
    // 13 gardening trowel
    // 14 plant cure
    // 15 bottomless bucket
    // 16 empty buckets
    // 17 normal compost
    // 18 supercompost
    // 19 ultracompost
    //
    // (child of FIXED_VIEWPORT_BANK_CONTAINER)
//    group 126
//    1 rake
//    2 dibber
//    3 spade
//    4 secateurs
//    5 watering can
//            6 trowel
//    7 plant cure
//            8 bmless bucket
//            9 buckets
//    10 compost
//    11 supercompost
//    12 ultracompost



    public void catherby() {
        plugin.sniper.castSpell("Camelot Teleport");
    }

    //


    @Override
    void setStartItems() {
        int currentLevel = plugin.client.getRealSkillLevel(Skill.FARMING);
        setRequestedInventory(currentLevel, true, true, true, true,
                        false, false);
    }

    @Override
    void run() {
        log.info("gettin");
        Widget w = plugin.client.getWidget(WidgetInfo.LEPRECHAUN_WITHDRAW_SUPERCOMPOST);

        if (w != null) {
            plugin.drawer = w.getBounds();
            Sniper.TargetWidget t = new Sniper.TargetWidget(w);
            sniper.snipe(t, 1, 4000);
        }
        log.info("gotters");
    }



}
