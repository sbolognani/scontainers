package net.runelite.client.plugins.vroedoe;

import naturalmouse.api.SystemCalls;
import naturalmouse.tools.SystemDiagnosis;
import net.runelite.api.KeyCode;
import org.testng.annotations.Test;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.security.Key;

//package net.runelite.client.plugins.vroedoe;
//
//import org.apache.commons.lang3.tuple.Triple;
//
//import javax.inject.Inject;
//import java.util.HashMap;
//
public class Fletcher {
    Eskedit e = new Eskedit();

    public Fletcher() throws AWTException {
    }

    @Test
    public void wat() throws InterruptedException {
        Thread cancer = e.holdKeyIndefinitely(KeyEvent.VK_SHIFT);
        for (int i=0; i<5; i++) {
            e.keyRelease(KeyEvent.VK_SHIFT);
            e.keyRelease(KeyEvent.VK_SHIFT);
            Thread.sleep(100);
            cancer.interrupt();
            e.type("watagua");
            cancer = e.holdKeyIndefinitely(KeyEvent.VK_SHIFT);
            e.type("watagua");
        }
        cancer.interrupt();
    }

    @Test
    public void cancer() {
        SystemDiagnosis.validateMouseMovement();
    }
}

//
//    private Triple<String, Integer, Integer> setFletchingTargetInventory(int currentLevel,
//                                                                         boolean stringing,
//                                                                         boolean cutting) {
//        System.out.println("Welcome to setfletchingInventory");
//        HashMap<Integer, Inventory.Item> requestedItems = new HashMap<>();
//        int LOGS_AMOUNT = 0;
//        int BOWSTRING_AMOUNT = 0;
//        String CUTBUTTON = null;
//
//        int KNIFE_ID = 946;
//        int BOWSTRING_ID = 1777;
//
//        if (cutting) {
//            if (stringing) {
//                LOGS_AMOUNT = 13;
//            } else {
//                LOGS_AMOUNT = 27;
//            }
//        }
//        if (stringing && cutting) {
//            BOWSTRING_AMOUNT = 13;
//        } else if (stringing) {
//            BOWSTRING_AMOUNT = 14;
//        }
//
//        Inventory.Item bowstring = new Inventory.Item(BOWSTRING_ID, BOWSTRING_AMOUNT, false);
//        if (BOWSTRING_AMOUNT != 0) {
//            requestedItems.put(bowstring.id, bowstring);
//        }
//
//        int woodID = -1;
//        int unstrungID = -1;
//
//        // Normal
//        if (currentLevel < 5) {
//            woodID = 1511;
//            CUTBUTTON = "1";
//        } else if (currentLevel < 10) {
//            woodID = 1511;
//            unstrungID = 50;
//            CUTBUTTON = "3";
//        } else if (currentLevel < 20) {
//            woodID = 1511;
//            unstrungID = 48;
//            CUTBUTTON = "4";
//        }
//
//        // Oak
//        else if (currentLevel < 25) {
//            woodID = 1521;
//            unstrungID = 54;
//            CUTBUTTON = "2";
//        } else if (currentLevel < 35) {
//            woodID = 1521;
//            unstrungID = 56;
//            CUTBUTTON = "3";
//        }
//
//        // Willow
//        else if (currentLevel < 40) {
//            woodID = 1519;
//            unstrungID = 60;
//            CUTBUTTON = "2";
//        } else if (currentLevel < 50) {
//            woodID = 1519;
//            unstrungID = 58;
//            CUTBUTTON = "3";
//        }
//
//        // Maple
//        else if (currentLevel < 55) {
//            woodID = 1517;
//            unstrungID = 64;
//            CUTBUTTON = "2";
//        } else if (currentLevel < 65) {
//            woodID = 1517;
//            unstrungID = 62;
//            CUTBUTTON = "3";
//        }
//
//        // Yew, skipping yew short
//        else if (currentLevel < 70) {
////            woodID = 1515;
////            unstrungID = 68;
////            CUTBUTTON = "2";
//            woodID = 1517;
//            unstrungID = 62;
//            CUTBUTTON = "3";
//        } else if (currentLevel < 80) {
//            woodID = 1515;
//            unstrungID = 66;
//            CUTBUTTON = "3";
//        }
//
//        // Magic, skipping magic short
//        else if (currentLevel < 85) {
////            woodID = 1513;
////            unstrungID = 72;
////            CUTBUTTON = "2";
//            woodID = 1515;
//            unstrungID = 66;
//            CUTBUTTON = "3";
//        } else if (currentLevel < 99) {
//            woodID = 1513;
//            unstrungID = 70;
//            CUTBUTTON = "3";
//        }
//
//        if (cutting) {
//            Inventory.Item knife = new Inventory.Item(KNIFE_ID, 1, false);
//            requestedItems.put(knife.id, knife);
//            Inventory.Item logs = new Inventory.Item(woodID, LOGS_AMOUNT, false);
//            requestedItems.put(logs.id, logs);
//        } else {
//            Inventory.Item unstrung = new Inventory.Item(unstrungID, BOWSTRING_AMOUNT, false);
//            requestedItems.put(unstrung.id, unstrung);
//        }
//
//        inv.setRequestedItems(requestedItems);
//        inv.updateInventory();
//
//        return Triple.of(CUTBUTTON, woodID, unstrungID);
//    }
//
//}
//
//private Boolean fletch(int inventories,
//        boolean stringing,
//        boolean cutting) {
//
//        if (this.inv == null) {
//        this.inv = new Inventory();
//        banker = new Banker(this);
//        }
//        // inventoryMenu
//        sniper.typeKeycode(KeyEvent.VK_ESCAPE);
//        int startTime = (int) (System.currentTimeMillis() / 1000);
//        System.out.println("Fletching from " + startTime);
//
//        int KNIFE_ID = 946;
//        int BOWSTRING_ID = 1777;
//
//        for (int i = 0; i < inventories; i++) {
//
//        int currentLevel = client.getRealSkillLevel(Skill.FLETCHING);
//        if (!(currentLevel == client.getBoostedSkillLevel(Skill.FLETCHING))) {
//        System.out.println("TODO: statRestore procedure");
//        return null;
//        }
//
//        Triple<String, Integer, Integer> buttonWoodUnstrung = setFletchingTargetInventory(currentLevel, stringing, cutting);
//
//        String OPTIONBUTTON = buttonWoodUnstrung.getLeft();
//        int WOOD_ID = buttonWoodUnstrung.getMiddle();
//        int UNSTRUNG_ID = buttonWoodUnstrung.getRight();
//
//        System.out.println("Withdrawing bank Items call from plugin");
//        Boolean withdrew = banker.withdrawBankItems();
//
//        if (withdrew == null) {
//        System.out.println("Failed on withdrawBankItems");
//        return null;
//        }
//
//        if (cutting) {
//        useSelectWait(KNIFE_ID, WOOD_ID, OPTIONBUTTON, WOOD_ID, Skill.FLETCHING, 55);
//        }
//
//        if (stringing) {
//        useSelectWait(BOWSTRING_ID, UNSTRUNG_ID, "1", UNSTRUNG_ID, Skill.FLETCHING, 55);
//        }
//
//        System.out.println("Miles Davis");
//        sleeprand(0, 15000); // TODO sample skewed normal
//        }
//        return true;
//        }
//
