package net.runelite.client.plugins.vroedoe;

import net.runelite.api.Item;

import javax.inject.Inject;

public class Gear {

    @Inject
    private final VroedoePlugin plugin;

    public Gear(VroedoePlugin plugin) {
        this.plugin = plugin;
    }



    public boolean isItemEquipped(int itemID) {
        System.out.println("Is equipped???");
//        ItemContainer equipmentContainer = plugin.EQUIPMENT_CONTAINER;
        Item[] items = plugin.EQUIPPED_ITEMS;

        if (items != null) {
            for (Item item : items) {
                System.out.println("Getting item id");
                if (itemID == item.getId()) {
                    System.out.println(item.toString());
                    return true;
                }
            }
        }
        return false;
    }

    public boolean canEquip(int itemID) {
        return false;
    }
}
