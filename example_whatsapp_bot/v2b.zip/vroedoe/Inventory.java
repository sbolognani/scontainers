package net.runelite.client.plugins.vroedoe;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.SpritePixels;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetItem;
import org.apache.commons.lang3.tuple.Pair;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Set;

import static java.lang.Math.abs;
import static java.lang.Math.floor;

@Singleton
@Slf4j
public class Inventory {

    @Inject
    private final VroedoePlugin plugin;

    public int INVENTORY_SIZE = 28;

    public HashMap<Integer, Item> carryingItems = new HashMap<>();
    public HashMap<Integer, Item> requestedItems = new HashMap<>();
    public HashMap<Integer, Item> redundantItems = new HashMap<>();
    public HashMap<Integer, Item> dropperItems = new HashMap<>();
    public HashMap<Integer, Item> missingItems = new HashMap<>();

    public Widget inventoryWidget = null;

    public int lastMenuOptionX;

    public Item newItem(int id, int amount, boolean noted) {
        return new Item(id, amount, noted);
    }

    public static class Item {

        public int id;
        public int amount;
        public boolean noted;

        public boolean equipped;

        public String withdrawalMethod;
        public String depositMethod;
        public boolean withdraw;
        public boolean deposit;
        public boolean pickup;
        public boolean equip;
        public boolean drop;
        public boolean alch;
        public boolean use;

        public BufferedImage sprite = null;

        public ArrayList<Pair<Integer, Integer>> inventoryPositions;
        public ArrayList<Integer> inventoryIndices;

        public Item(int id, int amount, boolean noted) {

            this.withdraw = true;
            this.id = id;
            this.amount = amount;
            this.noted = noted; // Unsupported
        }
    }

    public Inventory(VroedoePlugin plugin) {
        this.plugin = plugin;
    }

    public void printers() {
        updateInventory();
        System.out.println(requestedItems.size() + ", " + carryingItems.size() + ", " + missingItems.size() + ", " + redundantItems.size());
        for (Item item : carryingItems.values()) {
            System.out.println("Carrying " + item.amount + " of " + item.id + " at " + item.inventoryIndices);
        }
        for (Item item : missingItems.values()) {
            System.out.println("Missing " + item.amount + " of " + item.id);
        }
    }

    public int getFreeSpace() {
        carryingItems = setCarrying();
        int freeSpace = INVENTORY_SIZE;
        for (Item item : carryingItems.values()) {
            if (!item.equipped) {
                freeSpace -= item.inventoryIndices.size();
            }
        }
        return freeSpace;
    }

    public void addRequestedItems(HashMap<Integer, Item> request) {
        for (Item item : request.values()) {
            if (requestedItems.containsKey(item.id)) {
                item.amount += requestedItems.get(item.id).amount;
            }
            requestedItems.put(item.id, item);
        }
    }

    public void addRequestedEquipment(HashMap<Integer, Item> request) {

    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    // TODO Breaks when some are noted and some are not of same id >>> id noted is id normal + 1?
    public void updateInventory() {
//        log.info("Updating inventory");
        if (plugin.INVENTORY_WIDGET == null) {
            log.error("Inventory widget null");
            return;
        }
        carryingItems = setCarrying();
        missingItems.clear();
        redundantItems.clear();
        dropperItems.clear();

        for (Item requestedItem : requestedItems.values()) {
            if (!carryingItems.containsKey(requestedItem.id)) {
                if (!requestedItem.equipped) {
                    missingItems.put(requestedItem.id, requestedItem);
                }
            } else {
                Item carryingItem = carryingItems.get(requestedItem.id);
                carryingItem.equip = requestedItem.equip;
                if (carryingItem.amount < requestedItem.amount) {
                    Item missingItem = new Item(
                            requestedItem.id,
                            requestedItem.amount - carryingItem.amount,
                            requestedItem.noted
                    );
                    missingItems.put(missingItem.id, missingItem);
                }
            }
        }
        for (Item carryingItem : carryingItems.values()) {
            if (!requestedItems.containsKey(carryingItem.id)) {
                redundantItems.put(carryingItem.id, carryingItem);
            } else {
                Item requestedItem = requestedItems.get(carryingItem.id);
                if (carryingItem.amount > requestedItem.amount) {
                    Item redundantItem = new Item(
                            carryingItem.id,
                            carryingItem.amount - requestedItem.amount,
                            requestedItem.noted
                    );
                    redundantItems.put(redundantItem.id, redundantItem);
                }
            }
        }
        setWithdrawalMethods();
        setDepositMethods();
//        log.info("Updated inventory");
    }

    public HashMap<Integer, Item> getDropperItems() {
        for (Item carryingItem : carryingItems.values()) {
            if (carryingItem.drop) {
                dropperItems.put(carryingItem.id, carryingItem);
            }
        }
        return dropperItems;
    }

    public void setWithdrawalMethods() {
        for (Item missingItem : missingItems.values()) {
            if (missingItem.withdraw) {
                if (missingItem.amount == 1) {
                    missingItem.withdrawalMethod = "LEFT_CLICK";
                } else if (missingItem.amount == 5) {
                    missingItem.withdrawalMethod = "Withdraw-5";
                } else if (missingItem.amount == 10) {
                    missingItem.withdrawalMethod = "Withdraw-10";
                } else if (missingItem.amount == lastMenuOptionX) {
                    missingItem.withdrawalMethod = "Withdraw-" + missingItem.amount;
                } else {
                    missingItem.withdrawalMethod = "Withdraw-X";
                }
            }
        }
    }

    public void setDepositMethods() {

        Set<Integer> notRedundant = Sets.difference(carryingItems.keySet(), redundantItems.keySet());
        if (notRedundant.size() == 0) {
            // TODO bank whole invent with widgetbutton
            // Buggy, handle edge: all ids in redundant but want to keep x amount in invent
        }

        for (Item redundantItem : redundantItems.values()) {
            if (redundantItem.drop) {
                System.out.println("Marked to drop " + redundantItem.id);
            } else if (redundantItem.amount == 1) {
                redundantItem.depositMethod = "LEFT_CLICK";
            } else if (redundantItem.amount == carryingItems.get(redundantItem.id).amount) {
                redundantItem.depositMethod = "Deposit-All";
            } else if (redundantItem.amount < carryingItems.get(redundantItem.id).amount) {
                redundantItem.depositMethod = "Deposit-X";
            } else {
                System.out.println("Deposit how?");
            }
        }
    }

    public Collection<Integer> getCarryingToEquipIDs() {
        updateInventory();
        Collection<Integer> carryingToEquipIDs = new ArrayList<Integer>();
        for (Item carryingItem : carryingItems.values()) {
            if (carryingItem.equip) {
                carryingToEquipIDs.add(carryingItem.id);
            }
        }
        return carryingToEquipIDs;
    }

    private HashMap<Integer, Item> setCarrying() {
        carryingItems = new HashMap<>();

        for (WidgetItem itemWidget : plugin.INVENTORY_WIDGET_ITEMS) {
            int id = itemWidget.getId();
            if (id < 0) {
                continue; // Empty slot
            }
            // TODO main thread?
            int amount = itemWidget.getQuantity();
            if (!carryingItems.containsKey(id)) {
                ArrayList<Integer> inventoryIndeces = new ArrayList<>();
                ArrayList<Pair<Integer, Integer>> inventoryPositions = new ArrayList<>();
                inventoryIndeces.add(itemWidget.getIndex());
                inventoryPositions.add(inventoryIndexToPosition(itemWidget.getIndex()));
                Item item = new Item(id, amount, false);
                item.inventoryIndices = inventoryIndeces;
                item.inventoryPositions = inventoryPositions;
                carryingItems.put(id, item);
            } else {
                carryingItems.get(id).amount += amount;
                carryingItems.get(id).inventoryIndices.add(itemWidget.getIndex());
                carryingItems.get(id).inventoryPositions.add(inventoryIndexToPosition(itemWidget.getIndex()));
            }
        }
        return carryingItems;
    }

    public Pair<Integer, Integer> inventoryIndexToPosition(int index) {
        int row = (int) floor(index / 4.0);
        int column = index % 4;
        return Pair.of(row, column);
    }

    public Integer inventoryPositionToIndex(Pair<Integer, Integer> pos) {
        int index = 0;
        index += pos.getLeft() * 4;
        index += pos.getRight();
        return index;
    }

    public Integer getWidgetIndexByItemID(int id, boolean lowestIndexFirst, int neighbourIndex) {

        Item gameItem = carryingItems.get(id);
        if (gameItem == null) {
            System.out.println("CarryingItems did not contain key " + id);
            return null;
        }

        if (lowestIndexFirst) {
            return gameItem.inventoryIndices.get(0);

        } else {
            Pair<Integer, Integer> neighbour = inventoryIndexToPosition(neighbourIndex);
            for (Pair<Integer, Integer> pos : gameItem.inventoryPositions) {
                if ((abs(neighbour.getLeft() - pos.getLeft()) <= 1) &&
                        (abs(neighbour.getRight() - pos.getRight()) <= 1)) {
                    return inventoryPositionToIndex(pos);
                }
            }
        }
        return gameItem.inventoryIndices.get(0);
    }

    public WidgetItem getWidgetByItemID(int id, boolean lowestIndexFirst, int neighbourIndex) {
        return getWidgetByIndex(getWidgetIndexByItemID(id, lowestIndexFirst, neighbourIndex));
    }

    public WidgetItem getWidgetByIndex(int index) {
        return inventoryWidget.getWidgetItem(index);
    }

    public boolean isCarrying(int id) {
        updateInventory();
        return carryingItems.containsKey(id);
    }

    public boolean hasMissingItems() {
        updateInventory();
        return missingItems.size() > 0;
    }

    public boolean hasRedundantItems() {
        updateInventory();
        return redundantItems.size() > 0;
    }

}

