package net.runelite.client.plugins.vroedoe;

import net.runelite.api.ItemID;
import org.apache.commons.lang3.tuple.Triple;

import java.util.*;

public enum ItemSets {

    EMPTY_SET(Collections.emptyList()),

    QUICKY(Arrays.asList(
            Triple.of(ItemID.SARDINE, 10, false)
    )),

    VARROCK_TELEPORT(Arrays.asList(
            Triple.of(ItemID.LAW_RUNE, 1, false),
            Triple.of(ItemID.AIR_RUNE, 3, false),
            Triple.of(ItemID.FIRE_RUNE, 1, false)
    )),
    LUMBRIDGE_TELEPORT(Arrays.asList(
            Triple.of(ItemID.LAW_RUNE, 1, false),
            Triple.of(ItemID.AIR_RUNE, 3, false),
            Triple.of(ItemID.EARTH_RUNE, 1, false)
    )),
    CAMELOT_TELEPORT(Arrays.asList(
            Triple.of(ItemID.LAW_RUNE, 1, false),
            Triple.of(ItemID.AIR_RUNE, 5, false)
    )),
    FALADOR_TELEPORT(Arrays.asList(
            Triple.of(ItemID.LAW_RUNE, 1, false),
            Triple.of(ItemID.AIR_RUNE, 3, false),
            Triple.of(ItemID.WATER_RUNE, 1, false)
    )),
    ARDOUGNE_TELEPORT(Arrays.asList(
            Triple.of(ItemID.LAW_RUNE, 2, false),
            Triple.of(ItemID.WATER_RUNE, 2, false)
    )),
    TAVERLY_POD_BALLOON(Arrays.asList(
            Triple.of(ItemID.GRAND_SEED_POD, 1, false),
            Triple.of(ItemID.TINDERBOX, 1, false),
            Triple.of(ItemID.LOGS, 1, false)
    )),
    TAVERLY_DUEL_BALLOON(Arrays.asList(
            Triple.of(ItemID.RING_OF_DUELING8, 1, false),
            Triple.of(ItemID.TINDERBOX, 1, false),
            Triple.of(ItemID.LOGS, 1, false)
    )),
    GNOME_STRONGHOLD(Arrays.asList(
            Triple.of(ItemID.GRAND_SEED_POD, 1, false)
    ));

    HashMap<Integer, Inventory.Item> items;

    ItemSets(List<Triple<Integer, Integer, Boolean>> id_amount_noted_list) {
        this.items = new HashMap<>();

        for (Triple<Integer, Integer, Boolean> id_amount_noted : id_amount_noted_list) {
            Integer id = id_amount_noted.getLeft();
            Integer amount = id_amount_noted.getMiddle();
            Boolean noted = id_amount_noted.getRight();
            Inventory.Item item = new Inventory.Item(id, amount, noted);
            items.put(id, item);
        }
    }
}
