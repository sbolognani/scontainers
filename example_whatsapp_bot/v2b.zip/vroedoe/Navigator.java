package net.runelite.client.plugins.vroedoe;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.*;
import net.runelite.api.coords.WorldArea;
import net.runelite.api.coords.WorldPoint;

import javax.inject.Inject;
import javax.rmi.CORBA.Util;
import java.io.*;
import java.lang.reflect.Type;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

@Slf4j
public class Navigator {

    private static final int MAX_ACTOR_VIEW_RANGE = 16;
    public List<Pathfinder.TileNode> route;
    public List<Sniper.TargetTile> inRange = null;
    public List<Sniper.TargetTile> inDistanceRange = null;


    @Inject
    VroedoePlugin plugin;
    @Inject
    Client client;
    @Inject
    Sniper sniper;
    @Inject
    Inventory inventory;

    public final TileDict tileDict = new TileDict();
    public final Pathfinder pathfinder = new Pathfinder();
    public Sniper.TargetTile nextWalkTile = null;

    private static boolean isInViewRange(WorldPoint wp1, WorldPoint wp2) {
        int distance = wp1.distanceTo(wp2);
        return distance < MAX_ACTOR_VIEW_RANGE;
    }

    private static boolean isInDistanceRange(WorldPoint wp1, WorldPoint wp2, int minDist, int maxDist) {
        int distance = wp1.distanceTo(wp2);
        return (distance >= minDist && distance <= maxDist);
    }

    Navigator(VroedoePlugin plugin) {
        this.plugin = plugin;
        this.client = plugin.client;
        this.sniper = plugin.sniper;
        this.inventory = plugin.inv;
    }

    // Doors, entrances...
    // Teleports, boats...
    // Gather, HKK

    public class TileDict {

        Map<String, Pathfinder.TileInfo> tileInfoMap;
        Gson parser = new Gson();
        Type type = new TypeToken<Map<String, Pathfinder.TileInfo>>() {}.getType();

        TileDict() {
            readJson();
        }

        public void readJson() {
            try {
                String path = System.getProperty("user.dir");
                path += "/test.json";
                JsonReader reader = new JsonReader(new FileReader(path));
                this.tileInfoMap = parser.fromJson(reader, this.type);
                log.info("Read " + tileInfoMap.size() + " tiles");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        public void writeJson() {
            String json = parser.toJson(tileInfoMap);
            try {
                FileWriter writer = new FileWriter("test" + ".json");
                writer.write(json);
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public String worldPointToString(WorldPoint p) {
            return String.format("(%d, %d, %d)", p.getX(), p.getY(), p.getPlane());
        }

        public void update() {
            long s = System.currentTimeMillis();
            int plane = client.getPlane();
            Scene scene = client.getScene();
            Player player = client.getLocalPlayer();
            Tile[][][] tiles = scene.getTiles();
            Tile[][] planeTiles = tiles[plane];
            CollisionData[] d = client.getCollisionMaps();
            if (d == null) {
                return;
            }
            int[][] flags = d[plane].getFlags();
            if (player == null) {
                return;
            }
            WorldPoint playerWorldLocation = player.getWorldLocation();
            for (Tile[] planeTile : planeTiles) {
                for (Tile tile : planeTile) {
                    if (!isInViewRange(playerWorldLocation, tile.getWorldLocation())) {
                        continue;
                    }
                    String key = worldPointToString(tile.getWorldLocation());
                    if (!tileInfoMap.containsKey(key)) {
                        int flag = flags[tile.getSceneLocation().getX()][tile.getSceneLocation().getY()];
                        Pathfinder.TileInfo tileInfo = new Pathfinder.TileInfo(tile, flag);
                        tileInfoMap.put(tileInfo.key, tileInfo);
                    }
                }
            }
            writeJson();
//            System.out.println("WITH WRITE " + (System.currentTimeMillis() - s));
        }
    }

    public List<Pathfinder.TileNode> getRouteToDestination(WorldPoint currentWP, Destinations destination) {
        long s = System.currentTimeMillis();
        log.info("getRouteToDestination");
        WorldPoint targetWP = sampleFromDestination(destination);
        log.info("TargetWP: " + targetWP.toString());
        if (!pathfinder.graph.containsTile(targetWP)) {
            log.warn("Graph does not contain target tile" + targetWP.toString());  // Pathfinder already reloads()
            return null;
        } else if (!pathfinder.graph.containsTile(currentWP)) {
            log.warn("Graph does not contain player tile" + currentWP.toString());  // Pathfinder already reloads()
            return null;
        }
        Pathfinder.TileNode playerTN = pathfinder.graph.getTile(currentWP);
        Pathfinder.TileNode targetTN = pathfinder.graph.getTile(targetWP);
        List<Pathfinder.TileNode> route = pathfinder.graph.findRoute(playerTN, targetTN);
        if (route == null) {
            log.warn("No route found...");
            return null;
        }
        System.out.println("Found route to destination in: " + (System.currentTimeMillis() - s));
        return route;
    }

    public Boolean inDestination(Destinations destinations) {
        return (plugin.lastTickWP.getX() >= destinations.southWest.getX() &&
                plugin.lastTickWP.getY() >= destinations.southWest.getY() &&
                plugin.lastTickWP.getX() <= destinations.northEast.getX() &&
                plugin.lastTickWP.getY() <= destinations.northEast.getY());
    }

    public List<Sniper.TargetTile> routeTilesInRange(List<Pathfinder.TileNode> route, WorldPoint currentWP) {
//        log.info("RouteTilesInRange");
        List<Sniper.TargetTile> inRange = new ArrayList<>();
//        int baseX = plugin.BASE_X;
//        int baseY = plugin.BASE_Y;
//        Scene scene = plugin.SCENE;
        int baseX = client.getBaseX();
        int baseY = client.getBaseY();
        Scene scene = client.getScene();
        Tile[][][] sceneTiles = scene.getTiles();
//        log.info("got scene tiles: " + sceneTiles.length);
        for (Pathfinder.TileNode tn : route) {
            WorldPoint wp = tn.getWorldPoint();
            if (isInViewRange(wp, currentWP)) {
                Tile t = sceneTiles[wp.getPlane()][wp.getX() - baseX][wp.getY() - baseY];
                inRange.add(sniper.newTargetTile(t));
                Set<String> neighbours = pathfinder.graph.getNeighbors(tileDict.worldPointToString(wp));
                for (WorldPoint rwp : getRandPoints(wp, 3)) {
                    if (neighbours.contains(tileDict.worldPointToString(rwp))) {
                        t = sceneTiles[rwp.getPlane()][rwp.getX() - baseX][rwp.getY() - baseY];
                        inRange.add(sniper.newTargetTile(t));
                    }
                }
            }
        }
//        log.info("Route in rangerz");
        return inRange;
    }

    public WorldPoint getRandPoint(WorldPoint sourcePoint, int randRadius)
    {
        List<WorldPoint> losPoints = getRandPoints(sourcePoint, randRadius);
        return losPoints.get(Utils.unifInt(0, losPoints.size() - 1));
    }

    public List<WorldPoint> getRandPoints(WorldPoint sourcePoint, int randRadius) {
        {
            if (randRadius <= 0) {
                return new ArrayList<>(Collections.singleton(sourcePoint));
            }
//            log.info("start worldarea bullsht");
            WorldArea sourceArea = new WorldArea(sourcePoint, 1, 1);
            WorldArea possibleArea = new WorldArea(
                    new WorldPoint(sourcePoint.getX() - randRadius, sourcePoint.getY() - randRadius, sourcePoint.getPlane()),
                    new WorldPoint(sourcePoint.getX() + randRadius, sourcePoint.getY() + randRadius, sourcePoint.getPlane())
            );
            List<WorldPoint> possiblePoints = possibleArea.toWorldPointList();
            List<WorldPoint> losPoints = new ArrayList<>();
            losPoints.add(sourcePoint);
            for (WorldPoint point : possiblePoints) {
                if (sourceArea.hasLineOfSightTo(client, point)) {
                    losPoints.add(point);
                }
            }
//            log.info("end worldarea bs");
            return losPoints;
        }
    }

    public Boolean wonkyWalk(Destinations destination) {

        if (inDestination(destination)) {
            log.info("Destination reached!");
            inRange = null;
            return true;
        }
        WorldPoint currentWP = plugin.lastTickWP;
        route = getRouteToDestination(currentWP, destination);
        if (route == null) {
            log.error("Can't find route!");
            inRange = null;
            return false;
        }
        inRange = routeTilesInRange(route, currentWP);

        int inRangeLength = inRange.size();
        if (inRangeLength == 0) {
            log.error("No target tiles in range");
            inRange = null;
            return false;
        }


        int minMoveLength = Utils.unifInt(9, MAX_ACTOR_VIEW_RANGE);
        inDistanceRange = new ArrayList<>();
        for (Sniper.TargetTile target : inRange) {
            WorldPoint twp = target.tile.getWorldLocation();
//            log.info("got tile world location");
            if (isInDistanceRange(currentWP, twp, minMoveLength, MAX_ACTOR_VIEW_RANGE)) {
                inDistanceRange.add(target);
            }
        }

        if (inDistanceRange.size() > 0) {
            nextWalkTile = inDistanceRange.get(Utils.unifInt(0, inDistanceRange.size()-1));
        } else {
            nextWalkTile = inRange.get(Utils.unifInt(0, inRange.size()-1));
        }
        sniper.snipeMenu(nextWalkTile, "Walk here", 6000);
        long nextMoveTimeout = System.currentTimeMillis() + ThreadLocalRandom.current().nextInt(1500, 4000);
        while (plugin.isMoving || plugin.lastTickWP.distanceTo(nextWalkTile.tile.getWorldLocation()) > 2) {
            if (System.currentTimeMillis() > nextMoveTimeout) {
                break;
            }
            Utils.sleep(100);
        }

        return wonkyWalk(destination);
    }

    public WorldPoint sampleFromDestination(Destinations destination) {
        int x = Utils.unifInt(destination.southWest.getX(), destination.northEast.getX());
        int y = Utils.unifInt(destination.southWest.getY(), destination.northEast.getY());
        return new WorldPoint(x, y, destination.z);
    }


}
