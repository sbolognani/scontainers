package net.runelite.client.plugins.vroedoe;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import lombok.AllArgsConstructor;
import lombok.Getter;
import net.runelite.api.*;
import net.runelite.api.coords.WorldPoint;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.*;
import java.util.stream.Collectors;

public class Pathfinder {
    TileGraph graph;
    Pathfinder() {
        graph = new TileGraph();
    }

    @Test
    public void cancer() {

    }


    public interface GraphNode {
        String getId();
    }

    public class Graph<T extends GraphNode> {
        private final Set<T> nodes;
        private final Map<String, Set<String>> connections;

        public Graph(Set<T> nodes, Map<String, Set<String>> connections) {
            this.nodes = nodes;
            this.connections = connections;
        }

        public T getNode(String id) {
            return nodes.stream()
                    .filter(node -> node.getId().equals(id))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("No node found with ID"));
        }

        public Set<T> getConnections(T node) {
            return connections.get(node.getId()).stream()
                    .map(this::getNode)
                    .collect(Collectors.toSet());
        }
    }

    public interface Scorer<T extends GraphNode> {
        double computeCost(T from, T to);
    }

    class RouteNode<T extends GraphNode> implements Comparable<RouteNode> {
        private final T current;
        private T previous;
        private double routeScore;
        private double estimatedScore;

        RouteNode(T current) {
            this(current, null, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
        }

        RouteNode(T current, T previous, double routeScore, double estimatedScore) {
            this.current = current;
            this.previous = previous;
            this.routeScore = routeScore;
            this.estimatedScore = estimatedScore;
        }

        public T getCurrent() {
            return this.current;
        }
        public T getPrevious() {
            return this.previous;
        }
        public double getRouteScore() {
            return this.routeScore;
        }
        public void setPrevious(T t) {
            this.previous = t;
        }
        public void setRouteScore(double routeScore) {
            this.routeScore = routeScore;
        }
        public void setEstimatedScore(double estimatedScore) {
            this.estimatedScore = estimatedScore;
        }

        @Override
        public int compareTo(RouteNode other) {
            if (this.estimatedScore > other.estimatedScore) {
                return 1;
            } else if (this.estimatedScore < other.estimatedScore) {
                return -1;
            } else {
                return 0;
            }
        }
    }

    public class RouteFinder<T extends GraphNode> {
        private final Graph<T> graph;
        private final Scorer<T> nextNodeScorer;
        private final Scorer<T> targetScorer;

        public RouteFinder(Graph<T> graph, Scorer<T> nextNodeScorer, Scorer<T> targetScorer) {
            this.graph = graph;
            this.nextNodeScorer = nextNodeScorer;
            this.targetScorer = targetScorer;
        }

        public List<T> findRoute(T from, T to) {
            Queue<RouteNode> openSet = new PriorityQueue<>();
            Map<T, RouteNode<T>> allNodes = new HashMap<>();

            RouteNode<T> start = new RouteNode<>(from, null, 0d, targetScorer.computeCost(from, to));
            openSet.add(start);
            allNodes.put(from, start);
            while (!openSet.isEmpty()) {
                RouteNode<T> next = openSet.poll();
                if (next.getCurrent().equals(to)) {
                    List<T> route = new ArrayList<>();
                    RouteNode<T> current = next;
                    do {
                        route.add(0, current.getCurrent());
                        current = allNodes.get(current.getPrevious());
                    } while (current != null);
                    return route;
                }

                graph.getConnections(next.getCurrent()).forEach(connection -> {
                    RouteNode<T> nextNode = allNodes.getOrDefault(connection, new RouteNode<>(connection));
                    allNodes.put(connection, nextNode);

                    double newScore = next.getRouteScore() + nextNodeScorer.computeCost(next.getCurrent(), connection);
                    if (newScore < nextNode.getRouteScore()) {
                        nextNode.setPrevious(next.getCurrent());
                        nextNode.setRouteScore(newScore);
                        nextNode.setEstimatedScore(newScore + targetScorer.computeCost(connection, to));
                        openSet.add(nextNode);
                    }
                });
            }
            return null;
        }
    }

    public static String worldPointToString(WorldPoint p) {
        return String.format("(%d, %d, %d)", p.getX(), p.getY(), p.getPlane());
    }

    public static class TileInfo {
        int x;
        int y;
        int z;
        int[] objectIDs;
        int wallObjectID;
        Set<MovementFlag> flags;
        String key;

        TileInfo(Tile tile, int collisionData) {
            GameObject[] gameObjects = tile.getGameObjects();
            WallObject wallObject = tile.getWallObject();

            if (gameObjects != null) {
                objectIDs = Arrays.stream(gameObjects)
                        .filter(o -> !(o == null))
                        .mapToInt(GameObject::getId).toArray();
            }
            if (wallObject != null) {
                wallObjectID = wallObject.getId();
            }
            flags = MovementFlag.getSetFlags(collisionData);
            key = worldPointToString(tile.getWorldLocation());
            x = tile.getWorldLocation().getX();
            y = tile.getWorldLocation().getY();
            z = tile.getWorldLocation().getPlane();
        }
    }

    public class TileNode implements GraphNode {
        TileInfo tileInfo;

        TileNode(TileInfo tileInfo) {
            this.tileInfo = tileInfo;
        }

        @Override
        public String getId() {
            return this.tileInfo.key;
        }

        public WorldPoint getWorldPoint() {
            return new WorldPoint(tileInfo.x, tileInfo.y, tileInfo.z);
        }

    }

    public class TileDict {

        Map<String, TileInfo> map;
        Set<TileInfo> set;
        Set<TileNode> nodeSet = new HashSet<TileNode>();
        Map<String, TileNode> nodeMap =  new HashMap<String, TileNode>();
        Gson parser = new Gson();
        Type type = new TypeToken<Map<String, TileInfo>>() {}.getType();

        TileDict() {
            readJson();
            this.set = new HashSet<>(this.map.values());

            // Perform checks
            for (TileInfo tile: this.map.values()) {
                TileNode tileNode = new TileNode(tile);
                nodeMap.put(tile.key, tileNode);
                nodeSet.add(tileNode);
            }
        }

        public Map<String, TileInfo> readJson() {
            try {
                String path = System.getProperty("user.dir");
                path += "/test.json";
                JsonReader reader = new JsonReader(new FileReader(path));
                this.map = parser.fromJson(reader, this.type);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            return null;
        }

        public String xyzToKey(int x, int y, int z) {
            return String.format("(%d, %d, %d)", x, y, z);
        }

        public String wpToKey(WorldPoint wp) {
            return String.format("(%d, %d, %d)", wp.getX(), wp.getY(), wp.getPlane());
        }

    }

    public class TileGraph {

        TileDict tileDict = new TileDict();
        Set<TileNode> nodes;
        Map<String, Set<String>> connections = new HashMap<>();
        Graph<TileNode> graph;

        RouteFinder<TileNode> routeFinder;

        TileGraph() {
            reload();
        }

        public void reload() {
            long s = System.currentTimeMillis();
            this.tileDict = new TileDict();
            this.nodes = tileDict.nodeSet;
            for (TileNode tile: nodes) {
                connections.put(tile.tileInfo.key, getNeighbors(tile.tileInfo.key));
            }
            this.graph = new Graph<>(nodes, connections);
            routeFinder = new RouteFinder<TileNode>(this.graph, new AbsScorer(), new AbsScorer());
            System.out.println("Reload took: " + (System.currentTimeMillis() - s));
        }

        public List<TileNode> findRoute(TileNode start, TileNode stop) {
            System.out.println("Searching!");
            if (!nodes.contains(start)) {
                System.out.println("Start not in test.json...");
                return null;
            }
            if (!nodes.contains(stop)) {
                System.out.println("Stop not in test.json...");
                return null;
            }

            try {
                List<TileNode> route = routeFinder.findRoute(start, stop);
//                System.out.println(route.stream().map(TileNode::getId).collect(Collectors.toList()));
                return route;
            } catch (IllegalStateException e) {
                e.printStackTrace();
                return null;
            }
        }

        public TileNode getTile(int x, int y, int z) {
            String key = tileDict.xyzToKey(x, y, z);
            return tileDict.nodeMap.get(key);
        }

        public TileNode getTile(WorldPoint wp) {
            String key = tileDict.wpToKey(wp);
            return tileDict.nodeMap.get(key);
        }

        public Boolean containsTile(int x, int y, int z) {
            String key = tileDict.xyzToKey(x, y, z);
            if (!tileDict.nodeMap.containsKey(key)) {
                reload();
                return tileDict.nodeMap.containsKey(key);
            }
            return true;
        }

        public Boolean containsTile(WorldPoint wp) {
            String key = tileDict.wpToKey(wp);
            if (!tileDict.nodeMap.containsKey(key)) {
                reload();
                return tileDict.nodeMap.containsKey(key);
            }
            return true;
        }


        // Connect the neighbors
        public Set<String> getNeighbors(String id) {
            TileInfo tile = tileDict.map.get(id);
            Set<String> neighbors = new HashSet<>();
            if (tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_FULL)) {
                return neighbors;
            }
            String northKey = tileDict.xyzToKey(tile.x, tile.y+1, tile.z);
            if (tileDict.map.containsKey(northKey)
                    && !tileDict.map.get(northKey).flags.contains(MovementFlag.BLOCK_MOVEMENT_FULL)
                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_NORTH)) {
                neighbors.add(northKey);
            }
            String eastKey = tileDict.xyzToKey(tile.x+1, tile.y, tile.z);
            if (tileDict.map.containsKey(eastKey)
                    && !tileDict.map.get(eastKey).flags.contains(MovementFlag.BLOCK_MOVEMENT_FULL)
                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_EAST)) {
                neighbors.add(eastKey);
            }
            String southKey = tileDict.xyzToKey(tile.x, tile.y-1, tile.z);
            if (tileDict.map.containsKey(southKey)
                    && !tileDict.map.get(southKey).flags.contains(MovementFlag.BLOCK_MOVEMENT_FULL)
                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_SOUTH)) {
                neighbors.add(southKey);
            }
            String westKey = tileDict.xyzToKey(tile.x-1, tile.y, tile.z);
            if (tileDict.map.containsKey(westKey)
                    && !tileDict.map.get(westKey).flags.contains(MovementFlag.BLOCK_MOVEMENT_FULL)
                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_WEST)) {
                neighbors.add(westKey);
            }
//            String northeastKey = tileDict.xyzToKey(tile.x+1, tile.y+1, tile.z);
//            if (tileDict.map.containsKey(northeastKey)
//                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_NORTH_EAST)) {
//                neighbors.add(northeastKey);
//            }
//            String southeastKey = tileDict.xyzToKey(tile.x+1, tile.y-1, tile.z);
//            if (tileDict.map.containsKey(southeastKey)
//                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_SOUTH_EAST)) {
//                neighbors.add(southeastKey);
//            }
//            String southwestKey = tileDict.xyzToKey(tile.x-1, tile.y-1, tile.z);
//            if (tileDict.map.containsKey(southwestKey)
//                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_SOUTH_WEST)) {
//                neighbors.add(southwestKey);
//            }
//            String northwestKey = tileDict.xyzToKey(tile.x-1, tile.y+1, tile.z);
//            if (tileDict.map.containsKey(northwestKey)
//                    && !tile.flags.contains(MovementFlag.BLOCK_MOVEMENT_NORTH_WEST)) {
//                neighbors.add(northwestKey);
//            }
            return neighbors;
        }
    }

    public class AbsScorer implements Scorer<TileNode> {

        @Override
        public double computeCost(TileNode from, TileNode to) {
            return Math.abs(from.tileInfo.x - to.tileInfo.x) + Math.abs(from.tileInfo.y - to.tileInfo.y);
        }

    }

    @AllArgsConstructor
    enum MovementFlag {
        BLOCK_MOVEMENT_NORTH_WEST(CollisionDataFlag.BLOCK_MOVEMENT_NORTH_WEST),
        BLOCK_MOVEMENT_NORTH(CollisionDataFlag.BLOCK_MOVEMENT_NORTH),
        BLOCK_MOVEMENT_NORTH_EAST(CollisionDataFlag.BLOCK_MOVEMENT_NORTH_EAST),
        BLOCK_MOVEMENT_EAST(CollisionDataFlag.BLOCK_MOVEMENT_EAST),
        BLOCK_MOVEMENT_SOUTH_EAST(CollisionDataFlag.BLOCK_MOVEMENT_SOUTH_EAST),
        BLOCK_MOVEMENT_SOUTH(CollisionDataFlag.BLOCK_MOVEMENT_SOUTH),
        BLOCK_MOVEMENT_SOUTH_WEST(CollisionDataFlag.BLOCK_MOVEMENT_SOUTH_WEST),
        BLOCK_MOVEMENT_WEST(CollisionDataFlag.BLOCK_MOVEMENT_WEST),

        BLOCK_MOVEMENT_OBJECT(CollisionDataFlag.BLOCK_MOVEMENT_OBJECT),
        BLOCK_MOVEMENT_FLOOR_DECORATION(CollisionDataFlag.BLOCK_MOVEMENT_FLOOR_DECORATION),
        BLOCK_MOVEMENT_FLOOR(CollisionDataFlag.BLOCK_MOVEMENT_FLOOR),
        BLOCK_MOVEMENT_FULL(CollisionDataFlag.BLOCK_MOVEMENT_FULL);

        @Getter
        private int flag;

        /**
         * @param collisionData The tile collision flags.
         * @return The set of {@link MovementFlag}s that have been set.
         */
        public static Set<MovementFlag> getSetFlags(int collisionData) {
            return Arrays.stream(values())
                    .filter(movementFlag -> (movementFlag.flag & collisionData) != 0)
                    .collect(Collectors.toSet());
        }
    }
}
