package net.runelite.client.plugins.vroedoe;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ProtectedObject<O> {
    O object = null;
    ReadWriteLock lock = new ReentrantReadWriteLock();
    Lock writeLock = lock.writeLock();
    Lock readLock = lock.readLock();

    Boolean written = false;
    Boolean read = false;

    public void set(O object) {
        try {
            writeLock.lock();
            this.object = object;
            written = true;
        } finally {
            writeLock.unlock();
        }
    }
    public O get() {
        try {
            readLock.lock();
            return this.object;
        } finally {
            readLock.unlock();
        }
    }

    public Boolean wasWritten() {
        try {
            readLock.lock();
            return this.written;
        } finally {
            readLock.unlock();
        }
    }
}
