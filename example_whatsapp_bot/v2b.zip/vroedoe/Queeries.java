package net.runelite.client.plugins.vroedoe;

import com.sun.org.apache.xpath.internal.operations.Bool;

import javax.inject.Inject;
import java.lang.reflect.Array;

public class Queeries {

//    @Inject
//    VroedoePlugin plugin;
//
//    public Queeries(VroedoePlugin plugin) {
//        this.plugin = plugin;
//    }

    public class RequestedActor {
        String name;
        Boolean isAlive;
        String[] hasOption;

        RequestedActor(String name, Boolean isAlive, String... hasOption) {
            this.name = name;
            this.isAlive = isAlive;
            this.hasOption = hasOption;
        }
    }

}
