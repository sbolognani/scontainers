package net.runelite.client.plugins.vroedoe;

import net.runelite.api.Client;

import javax.inject.Inject;
import java.util.HashMap;

public abstract class Shell {

    @Inject
    VroedoePlugin plugin;
    @Inject
    Sniper sniper;
    @Inject
    Inventory inv;
    @Inject
    Banker banker;
    
    HashMap<Integer, Inventory.Item> startInventory = null;
    HashMap<Integer, Inventory.Item> startEquipment = null;
    String startLocation = null;
    String startUpMessage = null;

    abstract void setStartItems();
    abstract void run();
//    abstract void navigateToStart(); <-- Part of shello
//    abstract void setStartEquipment();

    // No blocking no client interaction
    public Shell(VroedoePlugin plugin) {

        this.plugin = plugin;
        assert plugin.sniper != null;
        assert plugin.banker != null;
        assert plugin.inv != null;
        this.inv = plugin.inv;
        this.sniper = plugin.sniper;
        this.banker = plugin.banker;
    }




}
