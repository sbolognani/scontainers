package net.runelite.client.plugins.vroedoe;

import lombok.extern.slf4j.Slf4j;
import naturalmouse.api.MouseMotion;
import naturalmouse.api.MouseMotionObserver;
import net.runelite.api.*;
import net.runelite.api.Point;
import net.runelite.api.coords.LocalPoint;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.api.widgets.WidgetItem;
import net.runelite.client.ui.ClientUI;
import net.runelite.client.util.ImageUtil;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Singleton;
import javax.rmi.CORBA.Util;
import javax.sound.sampled.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;


@Slf4j
@Singleton
public class Sniper implements MouseMotionObserver {

    @Inject
    private final VroedoePlugin plugin;

    @Inject
    public Eskedit eskedit;

    @Inject
    public Gear gear;

//    @Inject
//    public VroedoeOverlay overlay;

    Thread holdThread;

    public enum TabKey {

        COMBAT(KeyEvent.VK_F1),
        EXP(KeyEvent.VK_F2),
        QUESTS(KeyEvent.VK_F3),
        INVENTORY(KeyEvent.VK_ESCAPE),
        EQUIPMENT(KeyEvent.VK_F4),
        PRAYER(KeyEvent.VK_F5),
        SPELLBOOK(KeyEvent.VK_F6),
        CLAN(KeyEvent.VK_F7),
        FRIENDS(KeyEvent.VK_F8),
        MANAGEMENT(KeyEvent.VK_F9),
        LOGOUT(999),
        SETTINGS(KeyEvent.VK_F10),
        EMOTES(KeyEvent.VK_F11),
        MUSIC(KeyEvent.VK_F12);

        public final int keycode;

        TabKey(int keycode) {
            this.keycode = keycode;
        }
    }

    ;

    // TODO check success, runes available
    public void castSpell(String spell) {
        this.typeKeycode(TabKey.SPELLBOOK.keycode);
        Widget spellWidget = client.getWidget(Spells.getWidget(spell));
        if (spellWidget == null) {
            System.out.println("spellWidget null");
            return;
        }
        System.out.println(spellWidget.getWidgetItems());
        TargetWidget targetWidget = new TargetWidget(spellWidget);
        snipe(targetWidget, 1, 10000);
    }


    public void snipeEquippedRingOption(int itemID) {
        TargetWidget targetWidget = new TargetWidget(client.getWidget(WidgetInfo.EQUIPMENT_RING));
        if (!gear.isItemEquipped(itemID)) {
            System.out.println("Not wielding " + itemID);
        }
    }

    public void activateTab(Sniper.TabKey tab) {
        this.typeKeycode(tab.keycode);
    }

    int MENUWIDTH = 30;
    int MENUHEIGHT = 15;
    int MENUOFFSET = 19;

    public String targetMenuOption = "";

    BufferedImage crosshair = ImageUtil.getResourceStreamFromClass(getClass(), "crosshair.png");

    ProtectedObject<Target> target = new ProtectedObject<>();

    ArrayList<Target> targets = new ArrayList<>();

    int targetX = 0;
    int targetY = 0;

    Client client;
    ClientUI clientUI;

    Clip hitclip = null;
    AudioInputStream stream = null;

    public interface Target {
        Shape update();

        ProtectedObject<Shape> hull = new ProtectedObject<>();

        default void setHull() {
            Shape s = update();
            hull.set(s);
        }

        default Shape getHull() {
            return hull.get();
        }

        @Nullable
        default Point getClickPoint() {
            long timeout = System.currentTimeMillis() + 200;
            while (!hull.written) {  // TODO wait() instead?
                Utils.sleep(10);
                if (System.currentTimeMillis() > timeout) {
                    log.error("Timeout! What is your framerate?");
                    return null;
                }
            }
            Shape s = getHull();
            Rectangle r = s.getBounds();
            double x = 1 / (1 + Math.exp(-ThreadLocalRandom.current().nextGaussian()));
            double y = 1 / (1 + Math.exp(-ThreadLocalRandom.current().nextGaussian()));
            x = (r.getX() + r.getWidth() * x);
            y = (r.getY() + r.getHeight() * y);
            if (!s.contains(x, y)) {
                return getClickPoint();  // TODO how many calls?
            } else {
                return new Point((int) x, (int) y);
            }
        }

        default Integer getAngle() {
            // In degrees, 0 and 360 NORTH, 90 degrees EAST etc.
            Point targetPt = getClickPoint();
            if (targetPt == null) {
                return null;
            }
            double theta = Math.atan2(targetPt.getY() - VroedoePlugin.BOTTOM_CENTER.getY(), targetPt.getX() - VroedoePlugin.BOTTOM_CENTER.getX());
            theta += Math.PI / 2.0;
            double angle = Math.toDegrees(theta);
            if (angle < 0) {
                angle += 360;
            }
            return (int) angle;
        }

        ;
    }

    public static class TargetActor implements Target {
        Actor actor;

        public TargetActor(Actor actor) {
            this.actor = actor;
        }

        @Override
        public Shape update() {
            return actor.getConvexHull();
        }
    }

    public static class TargetWidget implements Target {
        Widget widget;

        public TargetWidget(Widget widget) {
            this.widget = widget;
        }

        @Override
        public Shape update() {
            return new Rectangle(
                    widget.getCanvasLocation().getX(),
                    widget.getCanvasLocation().getY(),
                    widget.getWidth(),
                    widget.getHeight()
            );
        }
    }

    public static class TargetWidgetItem implements Target {
        WidgetItem widgetItem;

        public TargetWidgetItem(WidgetItem widgetItem) {
            this.widgetItem = widgetItem;
        }

        @Override
        public Shape update() {
            return widgetItem.getCanvasBounds();
        }
    }

    public static class TargetObject implements Target {
        GameObject gameObject;

        public TargetObject(GameObject gameObject) {
            this.gameObject = gameObject;
        }

        @Override
        public Shape update() {
            return gameObject.getConvexHull();
        }
    }

    public static class TargetCustom implements Target {
        Shape box;

        public TargetCustom(Shape shape) {
            this.box = shape;
        }

        @Override
        public Shape update() {
            return box;
        }
    }

    public class TargetTile implements Target {
        Tile tile;

        public TargetTile(Tile tile) {
            this.tile = tile;
        }

        @Override
        public Shape update() {
            LocalPoint lp = LocalPoint.fromWorld(client, tile.getWorldLocation());
            if (lp == null) {
                return null;
            }
            return Perspective.getCanvasTilePoly(client, lp);
        }
    }

    public void hitmarkSound() {
        if (stream == null || hitclip == null) {
            return;
        }
        try {
            if (hitclip.isOpen()) {
                hitclip.stop();
                hitclip.setFramePosition(0);
            } else {
                hitclip.open(stream);
            }
            hitclip.start();
        } catch (IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }

    public Sniper(VroedoePlugin plugin) {
        this.plugin = plugin;
        this.client = plugin.client;
        this.clientUI = plugin.clientUI;
        System.out.println(plugin.client.getFPS());
        System.out.println("BBBBBBBBB");
        try {
            this.stream = ImageUtil.getAudioStreamFromClass(getClass(), "cod.wav");
            DataLine.Info info;
            {
                assert stream != null;
                info = new DataLine.Info(Clip.class, stream.getFormat());
            }
            this.hitclip = (Clip) AudioSystem.getLine(info);
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }

        try {
            this.eskedit = new Eskedit();
        } catch (AWTException e) {
            e.printStackTrace();
            return;
        }
        hitmarkSound();
    }

    public TargetTile newTargetTile(Tile t) {
        return new TargetTile(t);
    }

    private void setTarget(Target t) throws IllegalStateException {
        this.target.set(t);
    }

    public void rotateInRange(Target t) {
        // TODO Zoom
        int acceptMin = 45;
        int acceptMax = 315;
        int angle = t.getAngle();
        while (!((angle < acceptMin) || (angle > acceptMax))) {
            int holdMS = Utils.unifInt(50, 200);
            if (angle < 180) {
                eskedit.holdKey(KeyEvent.VK_LEFT, holdMS);
            }
            if (angle > 180) {
                eskedit.holdKey(KeyEvent.VK_RIGHT, holdMS);
            }
            Utils.sleep(holdMS);
            Utils.sleeprand(10, 50);
            angle = t.getAngle();
        }
        log.info("Rotated");
    }

    public final int MIN_SCALE = 181;
    public int CHILL_SCALE = 250;

    public Boolean zoomUntilContained(Target t) {
        synchronized (this) {
            try {
                wait(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (plugin.viewPortBounds == null) {
            log.info("VPB NULL");
            return false;
        }

        log.info("VPB" + plugin.viewPortBounds.toString());

        while (!plugin.viewPortBounds.contains(t.getHull().getBounds())) {
            if (client.getScale() < CHILL_SCALE) {
                log.warn("Target not in viewport after zooming");
                return false;
            }
            scroll(2);
            synchronized (this) {
                try {
                    wait(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return true;
    }

    public void rotateAndZoom(Target t) {
        rotateInRange(t);
        zoomUntilContained(t);
    }

    public void holdShift() {
        log.info("Shifting");
        if (holdThread != null) {
            log.error("Shifter not dead yet?");
            return;
        }
        holdThread = eskedit.holdKeyIndefinitely(KeyEvent.VK_SHIFT);
        Utils.sleep(200);
        log.info("shifted");
    }

    public void releaseShift() {
        log.info("Releasing");
        holdThread.interrupt();
        eskedit.keyRelease(KeyEvent.VK_SHIFT);
        log.info("Released");
        holdThread = null;
    }


    public int relHorizontal(int x) {
        return x + ClientUI.frame.getX() + clientUI.getCanvasOffset().getX();
    }

    public int relVertical(int y) {
        return y + ClientUI.frame.getY() + clientUI.getCanvasOffset().getY();
    }

    @Override
    public Boolean observe(int xPos, int yPos) {
        return target.get().getHull().contains(targetX, targetY);
    };

    private Point getxDestyDest(Point clickPoint) throws IllegalStateException {
        return new Point(relHorizontal(clickPoint.getX()), relVertical(clickPoint.getY()));
    }

    private MouseMotion getMotion(Point clickPoint) throws IllegalStateException {
        Point dest = getxDestyDest(clickPoint);
        return eskedit.currentMouseMotionFactory.build(dest.getX(), dest.getY());
    }

    public void moveMotion(MouseMotion motion) {
        try {
            motion.move(this);
        } catch (InterruptedException e) {
            log.error("Interrupted!");
            e.printStackTrace();
        }
    }

    public void click(int buttonID) {
        if (buttonID != 0) {
            eskedit.mousePressAndRelease(buttonID);
        }
        hitmarkSound();
        setTarget(null);
        log.info("Sniped");
    }

    public void type(String text) {
        this.eskedit.type(text);
    }

    public void typeKeycode(int code) {
        this.eskedit.typeKeycode(code);
    }

    public void scroll(int wheelAmt) {
        eskedit.mouseWheel(wheelAmt);
    }

    public Boolean snipe(Target t, int buttonID, int timeoutMS) throws IllegalStateException {
        if (t == null) {
            log.error("Target null");
            return false;
        }

        setTarget(t);

        synchronized (this) {
            try {
                wait(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        long deadline = System.currentTimeMillis() + 200;

        while (t.getHull() == null) {
            log.info("hull null");
            Utils.sleep(10);
            if (System.currentTimeMillis() > deadline) {
                log.error("Timeout! What is your framerate?");
                return false;
            }
        }

        if ((t instanceof TargetActor || t instanceof TargetTile)) {
            rotateAndZoom(t);
        }

        deadline = System.currentTimeMillis() + timeoutMS;

        while (System.currentTimeMillis() < deadline) {
            Point mousePosition = client.getMouseCanvasPosition();
            if (!t.getHull().contains(mousePosition.getX(), mousePosition.getY())) {
                Point clickPoint = t.getClickPoint();
                if (clickPoint == null) {
                    log.error("Could not get clickPoint");
                    return false;
                }
                MouseMotion motion = getMotion(clickPoint);
                this.targetX = clickPoint.getX();
                this.targetY = clickPoint.getY();
                moveMotion(motion);
            } else {
//                log.info("T" + t.getHull().getBounds().toString() + " contains " + mousePosition.toString());
                click(buttonID);
                return true;
            }
        }
        this.setTarget(null);
        log.warn("Sniper too slow!");
        return false; // Timeout
    }

    public Boolean snipeMenu(Target t, String menuOption, int timeoutMS) {
//        log.info("snipeMenu");
        snipe(t, 3, timeoutMS);
//        log.info("rightclicked");
        Utils.sleeprand(20, 60);
        Point openedPos = client.getMouseCanvasPosition();

        long to = System.currentTimeMillis() + timeoutMS;
        while (!client.isMenuOpen()) {
            Utils.sleep(20);
            if (System.currentTimeMillis() > to) {
                log.error("No open Menu within timeout");
                return false;
            }
        }
        MenuEntry[] menuEntries = client.getMenuEntries();
        boolean found = false;
        int pos = 0;
        for (int i = menuEntries.length - 1; i >= 0; i--) {
            String option = menuEntries[i].getOption();
            if (option.equals(menuOption)) {
                found = true;
                // MenuEntry[] newMenuEntries = new MenuEntry[]{menuEntries[i]};
                // client.setMenuEntries(newMenuEntries);
                break;
            }
            pos++;
        }
        if (!found) {
            log.error("Menu does not have this option");
            return false;
        }
        Rectangle s = new Rectangle(
                openedPos.getX() - MENUWIDTH,
                (openedPos.getY() + MENUOFFSET + (pos * MENUHEIGHT)), // TODO
                MENUWIDTH * 2,
                MENUHEIGHT
        );
        snipe(new TargetCustom(s), 1, 2000);
        return true;
    }
}
