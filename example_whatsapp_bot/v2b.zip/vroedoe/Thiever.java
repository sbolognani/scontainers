package net.runelite.client.plugins.vroedoe;

import lombok.extern.slf4j.Slf4j;
import net.runelite.api.ItemID;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;

@Slf4j
public class Thiever extends Shell {

    public Thiever(VroedoePlugin plugin) {
        super(plugin);
    }

    Set<Integer> keepSeeds = new HashSet<>(Arrays.asList(
            // Herbs
            ItemID.HARRALANDER_SEED,
            ItemID.RANARR_SEED,
            ItemID.TOADFLAX_SEED,
            ItemID.IRIT_SEED,
            ItemID.AVANTOE_SEED,
            ItemID.KWUARM_SEED,
            ItemID.SNAPDRAGON_SEED,
            ItemID.CADANTINE_SEED,
            ItemID.LANTADYME_SEED,
            ItemID.DWARF_WEED_SEED,
            ItemID.TORSTOL_SEED,
            // Allotments
            ItemID.SWEETCORN_SEED,
            ItemID.WATERMELON_SEED,
            ItemID.SNAPE_GRASS_SEED,
            // Flowers
            ItemID.NASTURTIUM_SEED,
            ItemID.LIMPWURT_SEED,
            // Bushes
            ItemID.WHITEBERRY_SEED,
            ItemID.POISON_IVY_SEED,
            // Other
            ItemID.BELLADONNA_SEED,
            ItemID.SPIRIT_SEED
    ));


    // The gate: 1558, 1560 (closed) and 1559, 1567 (open)

    @Override
    void setStartItems() {
//        plugin.inv.addRequestedItems(ItemSets.ARDOUGNE_TELEPORT.items);
        plugin.inv.addRequestedItems(EquipmentSets.THIEVER.items);
        plugin.inv.addRequestedItems(ItemSets.QUICKY.items);
    }

    int FOOD = ItemID.SARDINE;

    private Boolean navigateToStart() {
        return plugin.nav.wonkyWalk(Destinations.ARDY_NORTH_BANK);
    }

    void run() {
        setStartItems();
        int runsLeft = 2;
        while (runsLeft > 0) {
            inv.updateInventory();
            if (!inv.carryingItems.containsKey(FOOD) ||
                !plugin.isItemEquipped(ItemID.ARDOUGNE_CLOAK_2)) {
                boolean walked = navigateToStart();
                if (!walked) {
                    return;
                }
                boolean withdrew = banker.withdrawBankItems();
                if (!withdrew) {
                    return;
                }
            }
            Boolean walked = plugin.nav.wonkyWalk(Destinations.ARDY_MASTER_FARMER);
            if (!walked) {
                log.error("Did not walk to master farmer");
                return;
            }
            while (inv.isCarrying(FOOD)) {  // While conforming to start inventory and gear

                int minHealth = ThreadLocalRandom.current().nextInt(10, 60);
                if (minHealth > plugin.playerHealth) {
                    System.out.println("Eating at " + plugin.playerHealth);
                    plugin.clickInvItem(FOOD);
                }
                plugin.watchingNPCs.put("Master Farmer", "Pickpocket");
//                log.info("Awaiting Master Farmer");
                long timeoutMS = 10000;
                long s = System.currentTimeMillis() + timeoutMS;
                while (!plugin.nearestNPCs.containsKey("Master Farmer")) {
                    Utils.sleep(50);
                    if (System.currentTimeMillis() > s) {
                        log.error("Timeout");
                        return;
                    }
                }
                Sniper.TargetActor t = plugin.nearestNPCs.get("Master Farmer");
                sniper.snipe(t, 1, 5000);
                inv.updateInventory();
                for (Inventory.Item item : inv.carryingItems.values()) {
                    if (!keepSeeds.contains(item.id) &&
                        !(item.id == FOOD) &&
                        !inv.requestedItems.containsKey(item.id)) {
                        item.drop = true;
                    }
                }
                if (inv.getFreeSpace() < 2) {
                    for (Inventory.Item item : inv.carryingItems.values()) {
                        if (!keepSeeds.contains(item.id) &&
                                !(item.id == FOOD) &&
                                !inv.requestedItems.containsKey(item.id)) {
                            item.drop = true;
                        }
                    }
                    if (inv.getDropperItems().size() > 0) {
                        sniper.holdShift();
                        Utils.sleeprand(100, 300);
                        System.out.println(inv.getDropperItems().keySet());
                        plugin.dropInvItems(inv.getDropperItems().keySet());
                        Utils.sleeprand(50, 300);
                        sniper.releaseShift();
                    }
                }
                Utils.sleeprand(180, 1600);
            }
            plugin.watchingNPCs.remove("Master Farmer");
            runsLeft--;
        }
        log.info("Miles davis");
    }
}