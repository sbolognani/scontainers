package net.runelite.client.plugins.vroedoe;

import lombok.extern.slf4j.Slf4j;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.net.URL;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

@Slf4j
public class Utils {

    public static void sleeprand(int minms, int maxms) {
        int wait_before = ThreadLocalRandom.current().nextInt(minms, maxms);
        try {
            TimeUnit.MILLISECONDS.sleep(wait_before);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void sleep(int ms) {
        try {
            TimeUnit.MILLISECONDS.sleep(ms);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static int unifInt(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max + 1);
    }
}
