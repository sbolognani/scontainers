package net.runelite.client.plugins.vroedoe;

import net.runelite.api.*;

import net.runelite.api.Point;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.api.widgets.WidgetItem;
import net.runelite.client.ui.FontManager;
import net.runelite.client.ui.overlay.*;
import net.runelite.client.ui.overlay.components.TextComponent;
import net.runelite.client.util.ImageUtil;

import javax.inject.Inject;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Map;

public class VroedoeOverlay extends Overlay {

    private Client client;
    private VroedoePlugin plugin;
    private double theta = 0;

    @Inject
    private VroedoeOverlay(final Client client, final VroedoePlugin plugin)
    {
        setPosition(OverlayPosition.DYNAMIC);
        setLayer(OverlayLayer.ALWAYS_ON_TOP);
        setPriority(OverlayPriority.HIGH);
        this.client = client;
        this.plugin = plugin;
    }

    @Override
    public Dimension render(Graphics2D graphics) {

        final Point mouseLoc = client.getMouseCanvasPosition();

        final int crossX = mouseLoc.getX() - 36;
        final int crossY = mouseLoc.getY() - 36;
        final Point crossLoc = new Point(crossX, crossY);

//        Widget fixedView = plugin.client.getWidget(WidgetInfo.FIXED_VIEWPORT);
//        if (fixedView != null) {
//            graphics.setColor(Color.PINK);
//            graphics.draw(fixedView.getBounds());
//        }

        if (plugin.nav != null) {
            if (plugin.nav.inDistanceRange != null) {
                graphics.setColor(Color.BLUE);
                for (Sniper.TargetTile t : plugin.nav.inDistanceRange) {
                    t.setHull();
                    graphics.draw(t.getHull());
                }
            }
        }

        if (plugin.sniper.target != null) {
            graphics.setColor(Color.GREEN);
            Sniper.Target t = plugin.sniper.target.get();
            if (t != null) {
                t.setHull();
                Shape s = t.getHull();
                if (s != null) {
                    graphics.draw(s);
                }
            }
        }

        if (plugin.sniper != null) {
            synchronized (plugin.sniper) {
                plugin.sniper.notifyAll();
            }
        }

        for (String key : plugin.targetActors.keySet()) {
            NPC nearest = plugin.findNearestNPC("Banker", "Bank");
            Sniper.TargetActor t = new Sniper.TargetActor(nearest);
            plugin.targetActors.put(key, t);
        }

//        Point rinvLoc = new Point(0, 0);
//        if (plugin.inv != null) {
//            for (Inventory.Item item : plugin.inv.requestedItems.values()) {
//                if (item.sprite != null) {
//                    OverlayUtil.renderImageLocation(graphics, rinvLoc, item.sprite);
//                }
//            }
//        }

        if (VroedoePlugin.BOTTOM_CENTER != null) {
            graphics.drawLine(VroedoePlugin.BOTTOM_CENTER.getX(),
                    VroedoePlugin.BOTTOM_CENTER.getY(),
                    VroedoePlugin.BOTTOM_CENTER.getX() + 500,
                    VroedoePlugin.BOTTOM_CENTER.getY() + -500);
            graphics.drawLine(VroedoePlugin.BOTTOM_CENTER.getX(),
                    VroedoePlugin.BOTTOM_CENTER.getY(),
                    VroedoePlugin.BOTTOM_CENTER.getX() + -500,
                    VroedoePlugin.BOTTOM_CENTER.getY() + -500);
        }

//        BufferedImage crosshair = plugin.sniper.crosshair;
//        crosshair = ImageUtil.rotateImage(crosshair, theta);
//        OverlayUtil.renderImageLocation(graphics, crossLoc, crosshair);
//        theta += 1;
//        graphics.setColor(Color.WHITE);


        if (plugin.drawer != null) {
            graphics.draw(plugin.drawer);
        }


        return getBounds().getSize();
    }

}
