package net.runelite.client.plugins.vroedoe;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import net.runelite.api.Point;
import net.runelite.api.coords.LocalPoint;
import net.runelite.api.coords.WorldPoint;
import net.runelite.api.events.*;
import net.runelite.api.queries.*;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetID;
import net.runelite.api.widgets.WidgetInfo;

import net.runelite.api.widgets.WidgetItem;
import net.runelite.client.ui.ClientUI;

import com.google.inject.Provides;
import net.runelite.api.*;

import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.events.ConfigChanged;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;
import net.runelite.client.ui.overlay.OverlayManager;

import javax.annotation.Nullable;
import javax.inject.Inject;
import javax.inject.Singleton;
import java.awt.*;
import java.time.Instant;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;


import static java.lang.Math.*;
import static net.runelite.client.plugins.vroedoe.Banks.ALL_BANKS;


@SuppressWarnings("SpellCheckingInspection")
@PluginDescriptor(
        name = "Vroedoe",
        description = "Dit is Fraude",
        tags = {"config", "menu"},
        loadWhenOutdated = true,
        enabledByDefault = false
)

@Slf4j
@Singleton
public class VroedoePlugin extends Plugin {

    @Inject
    private OverlayManager overlayManager;

    @Inject
    public VroedoeOverlay overlay;

    @Inject
    private VroedoeConfig config;

    public VroedoePlugin() {
        System.out.println("AAAAAAAAAAAAAAAaa");
    }

    @Inject
    public ClientUI clientUI;

    @Inject
    public Client client; // 0
    public Queeries getr; // 1
    public Sniper sniper; // 1
    public Inventory inv; // 2
    public Navigator nav; // 2
    public Gear fabulous; // 2
    public Banker banker; // 3



    @Provides
    VroedoeConfig provideConfig(ConfigManager configManager) {
        return configManager.getConfig(VroedoeConfig.class);
    }

    ExecutorService control = Executors.newFixedThreadPool(1);

    Player player;

    Map<String, Sniper.TargetActor> nearestNPCs = new ConcurrentHashMap<>();
    Map<String, String> watchingNPCs = new ConcurrentHashMap<>();


    private static final String CONFIG_GROUP = "vroedoe";
    private static final String GIBS_MAGIC_CONFIG_FLAG = "gibsMagic";
    public static Point BOTTOM_CENTER = new Point(0, 0);

    private static final int MAX_ACTOR_VIEW_RANGE = 13;

    public Boolean inViewRange(GameObject gameObject) {
        if (client.getLocalPlayer() == null)
        {
            return false;
        }
        WorldPoint currentWP = client.getLocalPlayer().getWorldLocation();
        return currentWP.distanceTo(gameObject.getWorldLocation()) < MAX_ACTOR_VIEW_RANGE;
    }

    final int PIXELS_PER_WHEELAMT = 45;  // Sniper


    // TODO
    int logins = 0;
    int login_tries = 0;
    int max_login_tries = 0;
    Rectangle drawer = null;
    Rectangle drawer2 = null;

    Collection<NPC> npcs = null;

    @Override
    protected void startUp() throws Exception {

        this.sniper = new Sniper(this);

        if (clientUI == null) {
            System.out.println("CLIENTUINULL");
        } else {
            System.out.println("OFFSET: ");
            System.out.println(clientUI.getCanvasOffset());
        }
        overlayManager.add(overlay);
        GameState gameState = client.getGameState();
        if (gameState == GameState.LOGIN_SCREEN) {
            if (this.login_tries < this.max_login_tries) {
                login();
            }
        }
    }


    @Getter(AccessLevel.PACKAGE)
    private Instant lastTickUpdate;

    Boolean isMoving = true;
    Widget BANK_PIN_CONTAINER = null;
    Widget BANK_ITEM_CONTAINER = null;
    Widget BANK_DEPOSIT_INVENTORY = null;
    ItemContainer EQUIPMENT_CONTAINER = null;

    Widget RESIZABLE_VIEWPORT = null;


    Widget INVENTORY_WIDGET = null;
    Collection<WidgetItem> INVENTORY_WIDGET_ITEMS = null;

//    Integer BASE_X = null;
//    Integer BASE_Y = null;
//    Scene SCENE = null;

    Item[] EQUIPPED_ITEMS = null;
    int playerHealth = 0;
    LocalPoint lastTickLP = new LocalPoint(0, 0);
    WorldPoint lastTickWP = new WorldPoint(0, 0, 0);

//    public Map<String, String> watchingNPCs = new ConcurrentHashMap<>();
    public Map<String, Sniper.TargetActor> targetActors = new ConcurrentHashMap<>();
    public Map<String, Sniper.TargetObject> targetObjects = new ConcurrentHashMap<>();
    public Map<String, Sniper.TargetWidget> targetWidgets = new ConcurrentHashMap<>();
    public Map<String, Sniper.TargetTile> targetTiles = new ConcurrentHashMap<>();

//    public Map<Int> watchingWidgets = new

    Rectangle viewPortBounds = null;
    private void setViewPortBounds() {
        log.info("setting viewPortBounds");
        if (client.isResized()) {
            Widget w = client.getWidget(WidgetInfo.RESIZABLE_VIEWPORT_BOTTOM_LINE);
            if (w != null) {
                viewPortBounds = w.getBounds();
            }
        } else {
            Widget w = client.getWidget(WidgetInfo.FIXED_VIEWPORT);
            if (w != null) {
                viewPortBounds = w.getBounds();
            }
        }
    }

    @Subscribe
    public void onResizeableChanged(ResizeableChanged event) {
        log.info("resizeablechanged");
        setViewPortBounds();
    }

    @Subscribe
    public void onCanvasSizeChanged(CanvasSizeChanged event) {
        log.info("canvassizechanged");
        setViewPortBounds();
    }

    @Subscribe
    public void onGameTick(GameTick event) {
//        long s = System.currentTimeMillis();
        lastTickUpdate = Instant.now();
        if (!client.isClientThread()) {
            log.error("Not running on main thread");
            return;
        }
        if (player == null) {
            player = client.getLocalPlayer();
            return;
        }
        RESIZABLE_VIEWPORT = client.getWidget(WidgetInfo.RESIZABLE_VIEWPORT_BOTTOM_LINE);

        //        SCENE = client.getScene();
//        BASE_X = client.getBaseX();
//        BASE_Y = client.getBaseY();
        lastTickWP = player.getWorldLocation();
        LocalPoint currentLP = player.getLocalLocation();
        isMoving = lastTickLP.equals(currentLP);
        lastTickLP = currentLP;

        playerHealth = client.getBoostedSkillLevel(Skill.HITPOINTS);

        EQUIPMENT_CONTAINER = client.getItemContainer(InventoryID.EQUIPMENT);
        if (EQUIPMENT_CONTAINER != null) {
            EQUIPPED_ITEMS = EQUIPMENT_CONTAINER.getItems();
        }
        INVENTORY_WIDGET = client.getWidget(WidgetInfo.INVENTORY);
        if (INVENTORY_WIDGET != null) {
            INVENTORY_WIDGET_ITEMS = INVENTORY_WIDGET.getWidgetItems();
        }
        BANK_PIN_CONTAINER = client.getWidget(WidgetInfo.BANK_PIN_CONTAINER);
        BANK_ITEM_CONTAINER = client.getWidget(WidgetInfo.BANK_ITEM_CONTAINER);
        BANK_DEPOSIT_INVENTORY = client.getWidget(WidgetInfo.BANK_DEPOSIT_INVENTORY);


//        nearestNPCs = new ConcurrentHashMap<>();
//        for (String NPCname : watchingNPCs.keySet()) {
//            if (!nearestNPCs.containsKey(NPCname)) {
//                String mustHaveOption = watchingNPCs.get(NPCname);
//                NPC nearestNPC = findNearestNPC(NPCname, mustHaveOption);
//                Sniper.TargetActor t = new Sniper.TargetActor(nearestNPC);
//                nearestNPCs.put(NPCname, t);
//            }
//        }

        npcs = client.getNpcs();

        if (nav != null) {
            nav.tileDict.update();
        }
//        log.info("Handled tick in " + (System.currentTimeMillis()-s));
    }


    @Nullable
    public NPC findNearestNPC(
            String name,
            String mustHaveOptionString) {

        if (!client.isClientThread()) {
            log.error("Not running on main thread");
            return null;
        };

//        log.info("Finding " + name);
        List<NPC> matchedNPCs = new ArrayList<>();
        NPC nearestNPC = null;

        for (NPC npc : client.getNpcs()) {
            if (npc.getName() == null) {
                continue;
            }
            NPCComposition composition = npc.getComposition();
            if (!composition.isInteractible()
                    || !composition.isClickable()
                    || npc.getId() == 8666) { // Fix getActions()
                System.out.println("Bad composition or id");
                System.out.println(composition.isVisible() + " " + composition.isInteractible() + " " + composition.isClickable());
                continue;
            }

            if (npc.getName().equals(name)) {
//                if (npc.isDead() && mustBeAlive) {
//                    System.out.println("Npc is dead");
//                    continue;
//                }

                for (String action : composition.getActions()) {
                    if (action == null) {
                        continue;
                    } else if (action.equals(mustHaveOptionString)) {
                        break;
                    }
                }
                matchedNPCs.add(npc);
            }
        }

        if (matchedNPCs.size() == 0) {
            return null;
        }
        int closestDistance = Integer.MAX_VALUE;

        for (NPC npc : matchedNPCs) {
            int lpdist = lpDistance(lastTickLP, npc.getLocalLocation());
            int wpdist = wpDistance(lastTickWP, npc.getWorldLocation());
            if (wpdist > MAX_ACTOR_VIEW_RANGE) {
                continue;
            }
            if (lpdist < closestDistance) {
                closestDistance = lpdist;
                nearestNPC = npc;
            }
        }
        log.info("Found" + nearestNPC.getName());
        return nearestNPC;
    }

    public int lpDistance(LocalPoint lp1, LocalPoint lp2) {
        return lp1.distanceTo(lp2);
    }

    private static int wpDistance(WorldPoint wp1, WorldPoint wp2) {
        return wp1.distanceTo(wp2);
    }

//    @Subscribe
//    public void onNpcSpawned(NpcSpawned npcSpawned) {
//        final NPC npc = npcSpawned.getNpc();
//        final String npcName = npc.getName();
//    }

    @Subscribe
    public void onGameStateChanged(GameStateChanged gameStateChanged) throws InterruptedException {
        GameState gameState = gameStateChanged.getGameState();
        if (gameState == GameState.LOGIN_SCREEN) {
            if (this.login_tries < this.max_login_tries) {
                login();
            } else {
                return;
            }
        } else if (gameState == GameState.LOGGING_IN) {
            this.login_tries++;
        } else if (gameState == GameState.LOGGED_IN) {
//            clickHereToPlay();
            this.logins++;
        }
    }

    // --- MACRO ---
    public void login() {
        assert client.getGameState() == GameState.LOGIN_SCREEN;
        this.control.submit(() -> {
            sleeprand(2000, 5000); // TODO widgetLoaded
            sniper.type("\n");
            sniper.type("purenummer2@gmail.com\n");
            sniper.type("whatislove\n");
        });
    }


    // --- MACRO ---
    public void clickHereToPlay() {
        assert client.getGameState() == GameState.LOGGED_IN;
        sleeprand(2000, 3000);
        Rectangle target_box = new Rectangle(268, 293, 220, 90);
        Sniper.TargetCustom t = new Sniper.TargetCustom(target_box);
        sniper.snipe(t, 1, 3000);
    }

    public Point getBottomCenter() {
        Widget w = client.getWidget(WidgetInfo.FIXED_VIEWPORT);
        if (w == null) {
            return null;
        }
        Rectangle r = w.getBounds();
        int cx = (int) (r.getX() + r.getWidth())/2;
        int by = (int) (r.getY() + r.getHeight());
        System.out.println("BOTTOM_CENTER");
        return new Point(cx, by);
    }

    @Subscribe
    public void onMenuOptionClicked(final MenuOptionClicked event) {
        String option = event.getMenuOption();
//        System.out.println(event.getMenuOption() + " " + event.getWidgetId());
        if (sniper != null) {
            if (option.equals(sniper.targetMenuOption)) {
                log.info("Sniped " + option);
            }
        }
    }

    @Subscribe
    public void onWidgetLoaded(final WidgetLoaded event) {
        System.out.println(event.toString());
        client.getWidgetPositionsX();

        Widget w = client.getWidget(125, 0);
        if (event.getGroupId() == WidgetID.BANK_PIN_GROUP_ID) {
            System.out.println("Bank pin group id");
//            this.control.submit(this::enterBankPin);
        } else if (event.getGroupId() == WidgetID.INVENTORY_GROUP_ID) {
            System.out.println("Inventory group id");
            if (this.inv == null) {
                inv = new Inventory(this);
                nav = new Navigator(this);
                fabulous = new Gear(this);
                banker = new Banker(this);
            } else {
                inv.updateInventory();
            }
        } else if (event.getGroupId() == WidgetID.FIXED_VIEWPORT_GROUP_ID) {
            BOTTOM_CENTER = getBottomCenter();
            this.player = client.getLocalPlayer();
        }
    }

    public Boolean clickInvItem(int id) {
        if (!inv.isCarrying(id)) {
            System.out.println("Not carrying " + id);
            return false;
        }
        for (WidgetItem wi : INVENTORY_WIDGET_ITEMS) {
            if (wi.getId() == id) {
                Sniper.TargetWidgetItem widget = new Sniper.TargetWidgetItem(wi);
                sniper.snipe(widget, 1, 5000);
                log.info("Clicked inv item at index " + wi.getIndex());
                return true;
            }
        }
        return false;
    }

    public void equipAll() {
        inv.updateInventory();
        for (Integer id : inv.getCarryingToEquipIDs()) {
            if (!fabulous.isItemEquipped(id)) {
                clickInvItem(id);
            } else {
                inv.carryingItems.get(id).equipped = true;
            }
        }
    }

    public void dropInvItems(Collection<Integer> ids) {
        log.info("Dropping" + ids.toString());
//        for (int id : ids) {
//            clickInvItem(id);
//        }
        Collection<Sniper.TargetWidgetItem> dropWidgets = new ArrayList<>();
        for (WidgetItem wi : INVENTORY_WIDGET_ITEMS) {
            for (Integer id : ids) {
                if (id == wi.getId()) {
                    dropWidgets.add(new Sniper.TargetWidgetItem(wi));
                }
            }
        }
        for (Sniper.TargetWidgetItem tw : dropWidgets) {
            sniper.snipe(tw, 1, 10000);
        }
    }

    public Boolean useID1OnID2(int id1, int id2, boolean closestPair) {
        System.out.println("Using id1 on id2");

        int index1 = inv.getWidgetIndexByItemID(id1, true, 0);
        int index2 = inv.getWidgetIndexByItemID(id2, false, index1);

        Sniper.TargetWidgetItem widget1 = new Sniper.TargetWidgetItem(inv.getWidgetByIndex(index1));
        Sniper.TargetWidgetItem widget2 = new Sniper.TargetWidgetItem(inv.getWidgetByIndex(index2));

        if (widget1.widgetItem == null || widget2.widgetItem == null) {
            return null;
        }
        sniper.typeKeycode(Sniper.TabKey.INVENTORY.keycode);
        sniper.snipe(widget1,1, 10000);
        sniper.snipe(widget2, 1, 10000);
        return true;
    }

    public Boolean equip(Collection<Integer> itemIDs) {
        inv.updateInventory();
        sniper.typeKeycode(Sniper.TabKey.INVENTORY.keycode);  // TODO maybe inv is already activated
        sleeprand(20, 200);
        for (int id : itemIDs) {
            System.out.println("Equipping " + id);
            if (isItemEquipped(id)) {
                continue;
            }
            if (!inv.isCarrying(id)) {
                System.out.println("Not carrying " + id);
            }
            boolean clicked = clickInvItem(id);
            if (!clicked) {
                return false;
            }
            Inventory.Item equippedItem = inv.carryingItems.get(id);
            equippedItem.equipped = true;
        }
        System.out.println("Angle " + client.getMapAngle());
        sniper.typeKeycode(Sniper.TabKey.INVENTORY.keycode);
        return true;
    }

    public Boolean castle() {
        // 2564, 2562, 2560, ...
        sniper.typeKeycode(Sniper.TabKey.EQUIPMENT.keycode);
        Sniper.TargetWidget target = new Sniper.TargetWidget(client.getWidget(WidgetInfo.EQUIPMENT_RING));
        sniper.snipeMenu(target, "Castle Wars", 5000);
        sniper.typeKeycode(Sniper.TabKey.INVENTORY.keycode);
        return true;
    }

    public boolean isItemEquipped(int itemID) {

        ItemContainer equipmentContainer = client.getItemContainer(InventoryID.EQUIPMENT);

        if (equipmentContainer != null) {
            net.runelite.api.Item[] items = equipmentContainer.getItems();
            for (net.runelite.api.Item item : items) {
                if (itemID == item.getId()) {
                    System.out.println(item.toString() + " is equipped");
                    return true;
                }
            }
        }
        return false;
    }


    public Integer sleeprand(int minms, int maxms) {
        int wait_before = ThreadLocalRandom.current().nextInt(minms, maxms);
        try {
            TimeUnit.MILLISECONDS.sleep(wait_before);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return wait_before;
    }


    void scrollWhileWidgetNotContained(Widget w, Widget bankContainer) {
        System.out.println("Scroller");

        Sniper.TargetWidget target = new Sniper.TargetWidget(bankContainer);
        sniper.snipe(target, 0, 3000);

        Point windowLocation = bankContainer.getCanvasLocation();

        Rectangle bankItemsBox = new Rectangle(
                windowLocation.getX(),
                windowLocation.getY(),
                bankContainer.getWidth(),
                bankContainer.getHeight()
        );

        Point canvasLocation = w.getCanvasLocation();
        Rectangle getterBox = new Rectangle(
                canvasLocation.getX(),
                canvasLocation.getY(),
                w.getWidth(),
                w.getHeight()
        );

        // Whatislove
        int timeoutMS = 3000;
        long t = System.currentTimeMillis() + timeoutMS;
        while (!bankItemsBox.contains(getterBox) && System.currentTimeMillis() < t) {
            canvasLocation = w.getCanvasLocation();

            getterBox = new Rectangle(
                    canvasLocation.getX(),
                    canvasLocation.getY(),
                    w.getWidth(),
                    w.getHeight()
            );

            this.drawer2 = getterBox;

            double widgetTop = getterBox.getY();
            double widgetBottom = widgetTop + getterBox.getHeight();
            double bankBoxTop = bankItemsBox.getY();
            double bankBoxBottom = bankBoxTop + bankItemsBox.getHeight();

            int overshootAmt = ThreadLocalRandom.current().nextInt(0, 4); // Overshoot

            if (widgetTop < bankBoxTop) {
                double ydiff = bankBoxTop - widgetTop;
                int wheelAmt = -(int) ceil(ydiff / PIXELS_PER_WHEELAMT); // Scroll up
                if (wheelAmt < -1) {
                    wheelAmt -= overshootAmt;
                }
                sniper.scroll(wheelAmt);
            } else if (widgetBottom > bankBoxBottom) {
                double ydiff = widgetBottom - bankBoxBottom;
                int wheelAmt = (int) ceil(ydiff / PIXELS_PER_WHEELAMT); // Scroll down
                if (wheelAmt > 1) {
                    wheelAmt += overshootAmt;
                }
                sniper.scroll(wheelAmt);
            }
            sleeprand(300, 500);
        }
    }

    public Integer unif(int min, int max) {
        return ThreadLocalRandom.current().nextInt(min, max);
    }

    @Subscribe
    public void onItemContainerChanged(ItemContainerChanged event) {
        if (event.getContainerId() == InventoryID.INVENTORY.getId()) {
            if (this.inv == null) {
                return;
            }
            inv.updateInventory();
//            for (Inventory.Item item : inv.requestedItems.values()) {
//                if (item.sprite == null) {
//                    SpritePixels sp = client.createItemSprite(item.id, item.amount, 0, 0, 1, item.noted, 1);
//                    if (sp != null) {
//                        item.sprite = sp.toBufferedImage();
//                    }
//                }
//            }
        }
    }

//        if (event.getContainerId() == InventoryID.BANK.getId()) {
//            net.runelite.api.Item[] items = event.getItemContainer().getItems();
//            System.out.println(items.length + " items in the bank boi");
//        }

//    @Subscribe
//    public void onStatChanged(StatChanged event) {
//        Skill skill = event.getSkill();
//        int xp = event.getXp();
//        int level = event.getLevel();
//    }

    // TODO check for targetInventory instead of waitID
    private Boolean useSelectWait(int id1, int id2, String selectOption, int waitID, Skill skill, int maxWaitS) {
        int startLevel = client.getRealSkillLevel(skill);
        Boolean used = useID1OnID2(id1, id2, true);
        if (used == null) {
            return null;
        }

        // TODO listen for menuWidget event
        int mss = sleeprand(600, 1600);
        sniper.type(selectOption);
        if (mss < 800) {
            sleeprand(200, 400);
            sniper.type(selectOption);
        }

        for (int s = 0; s < maxWaitS; s++) {
            // TODO improve levelUp procedure
            if (startLevel != client.getRealSkillLevel(skill)) {
                for (int j = 0; j < unif(2, 5); j++) {
                    sniper.type(" ");
                    sleeprand(200, 1000);
                }
                useSelectWait(id1, id2, selectOption, waitID, skill, maxWaitS - s + 4);
            }
            if (inv.isCarrying(waitID)) {
                sleeprand(500, 1500); // TODO
            } else {
                break;
            }
        }
        // TODO did not finish in time?
        // TODO is invent target inventory?
        return true;
    }


    @Subscribe
    public void onConfigChanged(ConfigChanged event) {
        if (!CONFIG_GROUP.equals(event.getGroup())) {
            return;
        }
        if (event.getKey() == GIBS_MAGIC_CONFIG_FLAG) {
            System.out.println("Key issa flag");
        }
        if (config.gibsMagic()) {
            System.out.println("Issa gibs Magic");
            System.out.println(event.getNewValue());
        } else {
            System.out.println("Issa not gibs Magic");
            System.out.println(event.getNewValue());
        }
    }

    Shell m;

    // DELETE
    public void contiyaw() {
        int timeoutMS = 10000;
        long t = System.currentTimeMillis() + timeoutMS;        int maxyaw = 0;
        while (System.currentTimeMillis() < t) {
            int newyaw = client.getCameraYaw();
            if (newyaw > maxyaw) {
                maxyaw = newyaw;
                System.out.println(maxyaw);
            }
            Utils.sleep(5);
        }
    };

    @Subscribe
    public void onChatMessage(ChatMessage event) {
        MessageNode node = event.getMessageNode();
        String name = event.getName();
        String message = event.getMessage();
        ChatMessageType type = event.getType();
        String sender = event.getSender();
//        System.out.println(sender + " " + name + " " + message + " " + node.getName());
        int ts = event.getTimestamp();

        if (message.contains("123pc inv")) {
                inv.printers();
            }

//        if (message.contains("test1")) {
//            nav.getArdyMasterFarmerRoute();
//            nav.setTargetTiles();
//        }

        if (message.contains("gearboi")) {
            Collection<Integer> itemIDs = inv.getCarryingToEquipIDs();
            this.control.submit(() -> equip(itemIDs));
        }

        if (message.contains("setm")) {
            m = new Thiever(this);
        }

        if (message.contains("shiftergo")) {
            sniper.holdShift();
        }
        if (message.contains("shifterno")) {
            sniper.releaseShift();
        }

        if (message.contains("ardynorth")){
            nav.wonkyWalk(Destinations.ARDY_NORTH_BANK);
        }
        if (message.contains("ardymaster")) {
            nav.wonkyWalk(Destinations.ARDY_MASTER_FARMER);
        }

        if (message.contains("thievboi")) {
            m = new Thiever(this);
            this.control.submit(m::run);
        }

        if (message.contains("castleboi")) {
            this.control.submit(this::castle);
        }

        if (message.contains("farmerboi")) {
            m = new Farmer(this);
            this.control.submit(m::run);
        }

        if (message.contains("typerboi")) {
            sniper.type("Cancerboi DeluxaFlex A a");
        }

        if (message.contains("teleboi")) {
            this.control.submit(() -> sniper.castSpell("Camelot Teleport"));
        }

        if (message.contains("tbank")) {
            this.control.submit((banker::findBankerAndBank));
        }

        if (message.contains("twithdraw")) {
            this.control.submit((banker::withdrawBankItems));
        }

    }


    private boolean objectIdEquals(TileObject tileObject, int id) {
        if (tileObject == null) {
            return false;
        }

        if (tileObject.getId() == id) {
            return true;
        }

        // Menu action EXAMINE_OBJECT sends the transformed object id, not the base id, unlike
        // all of the GAME_OBJECT_OPTION actions, so check the id against the impostor ids
        final ObjectComposition comp = client.getObjectDefinition(tileObject.getId());

        if (comp.getImpostorIds() != null) {
            for (int impostorId : comp.getImpostorIds()) {
                if (impostorId == id) {
                    return true;
                }
            }
        }

        return false;
    }

    @Nullable
    public GameObject findNearestGameObject(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new GameObjectQuery()
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public GameObject findNearestGameObjectWithin(WorldPoint worldPoint, int dist, int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new GameObjectQuery()
                .isWithinDistance(worldPoint, dist)
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public GameObject findNearestGameObjectWithin(WorldPoint worldPoint, int dist, Collection<Integer> ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new GameObjectQuery()
                .isWithinDistance(worldPoint, dist)
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public NPC findNearestNpc(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new NPCQuery()
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public NPC findNearestNpc(String... names)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new NPCQuery()
                .nameContains(names)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public NPC findNearestNpcWithin(WorldPoint worldPoint, int dist, Collection<Integer> ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new NPCQuery()
                .isWithinDistance(worldPoint, dist)
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public NPC findNearestAttackableNpcWithin(WorldPoint worldPoint, int dist, String name, boolean exactnpcname)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        if (exactnpcname)
        {
            return new NPCQuery()
                    .isWithinDistance(worldPoint, dist)
                    .filter(npc -> npc.getName() != null && npc.getName().toLowerCase().equals(name.toLowerCase()) && npc.getInteracting() == null && npc.getHealthRatio() != 0)
                    .result(client)
                    .nearestTo(client.getLocalPlayer());
        }
        else
        {
            return new NPCQuery()
                    .isWithinDistance(worldPoint, dist)
                    .filter(npc -> npc.getName() != null && npc.getName().toLowerCase().contains(name.toLowerCase()) && npc.getInteracting() == null && npc.getHealthRatio() != 0)
                    .result(client)
                    .nearestTo(client.getLocalPlayer());
        }
    }

    @Nullable
    public NPC findNearestNpcTargetingLocal(String name, boolean exactnpcname)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        if (exactnpcname)
        {
            return new NPCQuery()
                    .filter(npc -> npc.getName() != null && npc.getName().toLowerCase().equals(name.toLowerCase()) && npc.getInteracting() == client.getLocalPlayer() && npc.getHealthRatio() != 0)
                    .result(client)
                    .nearestTo(client.getLocalPlayer());
        }
        else
        {
            return new NPCQuery()
                    .filter(npc -> npc.getName() != null && npc.getName().toLowerCase().contains(name.toLowerCase()) && npc.getInteracting() == client.getLocalPlayer() && npc.getHealthRatio() != 0)
                    .result(client)
                    .nearestTo(client.getLocalPlayer());
        }

    }

    @Nullable
    public WallObject findNearestWallObject(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new WallObjectQuery()
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public WallObject findWallObjectWithin(WorldPoint worldPoint, int radius, int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new WallObjectQuery()
                .isWithinDistance(worldPoint, radius)
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public WallObject findWallObjectWithin(WorldPoint worldPoint, int radius, Collection<Integer> ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new WallObjectQuery()
                .isWithinDistance(worldPoint, radius)
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public DecorativeObject findNearestDecorObject(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new DecorativeObjectQuery()
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    @Nullable
    public GroundObject findNearestGroundObject(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new GroundObjectQuery()
                .idEquals(ids)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }

    public List<GameObject> getGameObjects(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new GameObjectQuery()
                .idEquals(ids)
                .result(client)
                .list;
    }

    public List<GameObject> getLocalGameObjects(int distanceAway, int... ids)
    {
        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }
        List<GameObject> localGameObjects = new ArrayList<>();
        for(GameObject gameObject : getGameObjects(ids))
        {
            if(gameObject.getWorldLocation().distanceTo2D(client.getLocalPlayer().getWorldLocation())<distanceAway)
            {
                localGameObjects.add(gameObject);
            }
        }
        return localGameObjects;
    }

    public List<NPC> getNPCs(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new NPCQuery()
                .idEquals(ids)
                .result(client)
                .list;
    }

    public List<NPC> getNPCs(String... names)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new NPCQuery()
                .nameContains(names)
                .result(client)
                .list;
    }

    public NPC getFirstNPCWithLocalTarget()
    {
        assert client.isClientThread();

        List<NPC> npcs = client.getNpcs();
        for (NPC npc : npcs)
        {
            if (npc.getInteracting() == client.getLocalPlayer())
            {
                return npc;
            }
        }
        return null;
    }

    public List<WallObject> getWallObjects(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new WallObjectQuery()
                .idEquals(ids)
                .result(client)
                .list;
    }

    public List<DecorativeObject> getDecorObjects(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new DecorativeObjectQuery()
                .idEquals(ids)
                .result(client)
                .list;
    }

    public List<GroundObject> getGroundObjects(int... ids)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }

        return new GroundObjectQuery()
                .idEquals(ids)
                .result(client)
                .list;
    }

    @Nullable
    public TileObject findNearestObject(int... ids)
    {
        GameObject gameObject = findNearestGameObject(ids);

        if (gameObject != null)
        {
            return gameObject;
        }

        WallObject wallObject = findNearestWallObject(ids);

        if (wallObject != null)
        {
            return wallObject;
        }
        DecorativeObject decorativeObject = findNearestDecorObject(ids);

        if (decorativeObject != null)
        {
            return decorativeObject;
        }

        return findNearestGroundObject(ids);
    }

    @Nullable
    public List<TileItem> getTileItemsWithin(int distance)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }
        return new TileQuery()
                .isWithinDistance(client.getLocalPlayer().getWorldLocation(), distance)
                .result(client)
                .first()
                .getGroundItems();
    }

    @Nullable
    public List<TileItem> getTileItemsAtTile(Tile tile)
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return new ArrayList<>();
        }
        return new TileQuery()
                .atWorldLocation(tile.getWorldLocation())
                .result(client)
                .first()
                .getGroundItems();
    }

    @Nullable
    public GameObject findNearestBank()
    {
        assert client.isClientThread();

        if (client.getLocalPlayer() == null)
        {
            return null;
        }

        return new GameObjectQuery()
                .idEquals(ALL_BANKS)
                .result(client)
                .nearestTo(client.getLocalPlayer());
    }


    public List<Item> getEquippedItems()
    {
        assert client.isClientThread();

        List<Item> equipped = new ArrayList<>();
        Item[] items = client.getItemContainer(InventoryID.EQUIPMENT).getItems();
        for (Item item : items)
        {
            if (item.getId() == -1 || item.getId() == 0)
            {
                continue;
            }
            equipped.add(item);
        }
        return equipped;
    }


    public boolean isItemEquipped(Collection<Integer> itemIds)
    {
        assert client.isClientThread();

        Item[] items = client.getItemContainer(InventoryID.EQUIPMENT).getItems();
        for (Item item : items)
        {
            if (itemIds.contains(item.getId()))
            {
                return true;
            }
        }
        return false;
    }

    public WidgetInfo getSpellWidgetInfo(String spell)
    {
        assert client.isClientThread();
        return Spells.getWidget(spell);
    }

    public WidgetInfo getPrayerWidgetInfo(String spell)
    {
        assert client.isClientThread();
        return PrayerMap.getWidget(spell);
    }

    public Widget getSpellWidget(String spell)
    {
        assert client.isClientThread();
        return client.getWidget(Spells.getWidget(spell));
    }

    public Widget getPrayerWidget(String spell)
    {
        assert client.isClientThread();
        return client.getWidget(PrayerMap.getWidget(spell));
    }



}


