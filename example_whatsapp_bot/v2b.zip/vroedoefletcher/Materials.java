package net.runelite.client.plugins.vroedoefletcher;

public class Materials {
}
