package net.runelite.client.plugins.vroedoefletcher;

public interface vroedoeFletcherConfig {

}
