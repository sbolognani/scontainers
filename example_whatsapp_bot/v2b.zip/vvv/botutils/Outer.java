package net.runelite.client.plugins.vvv.botutils;

import java.util.List;
import net.runelite.api.coords.WorldPoint;

class Outer
{
	public List<WorldPoint> path;
}