package net.runelite.client.plugins.vvv.imagiccaster.src.main.java.net.runelite.client.plugins.imagiccaster;

public enum iMagicCasterState
{
	FIND_ITEM,
	FIND_NPC,
	HANDLE_BREAK,
	IDLING,
	ITEM_NOT_FOUND,
	MOVING,
	NPC_NOT_FOUND
}
