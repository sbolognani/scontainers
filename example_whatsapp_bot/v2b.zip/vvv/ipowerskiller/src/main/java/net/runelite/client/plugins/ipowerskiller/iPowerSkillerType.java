package net.runelite.client.plugins.vvv.ipowerskiller.src.main.java.net.runelite.client.plugins.ipowerskiller;

public enum iPowerSkillerType
{
	DENSE_ESSENCE,
	SANDSTONE,
	GAME_OBJECT,
	NPC,
	WALL_OBJECT
}
