package net.runelite.client.plugins.vvv.irooftopagility.src.main.java.net.runelite.client.plugins.irooftopagility;

public enum iRooftopAgilityObstacleType
{
	NORMAL,
	DECORATION,
	GROUND_OBJECT
}
