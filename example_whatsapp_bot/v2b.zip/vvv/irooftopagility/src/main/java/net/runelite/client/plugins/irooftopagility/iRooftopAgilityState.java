package net.runelite.client.plugins.vvv.irooftopagility.src.main.java.net.runelite.client.plugins.irooftopagility;

public enum iRooftopAgilityState
{
	ANIMATING,
	CAST_CAMELOT_TELEPORT,
	FIND_OBSTACLE,
	HANDLE_BREAK,
	HIGH_ALCH,
	MARK_OF_GRACE,
	MOVING,
	PRIFF_PORTAL,
	RESTOCK_ITEMS,
	TIMEOUT;
}
