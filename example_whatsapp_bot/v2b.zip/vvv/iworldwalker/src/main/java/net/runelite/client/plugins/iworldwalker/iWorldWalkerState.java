package net.runelite.client.plugins.vvv.iworldwalker.src.main.java.net.runelite.client.plugins.iworldwalker;

public enum iWorldWalkerState
{
	ANIMATING,
	ITERATING,
	MOVING,
	TIMEOUT;
}
