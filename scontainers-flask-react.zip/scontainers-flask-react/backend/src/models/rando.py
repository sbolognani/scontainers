from typing import Optional, Dict, Any
from random import random

from ..database import db


class Rando(db.Model):  # type: ignore
    key = db.Column(db.Integer, primary_key=True)
    val = db.Column(db.String(256))

    @classmethod
    def generate(cls) -> "Rando":
        return cls(key=None, val=str(random()))

    def serialize(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "val": self.val,
        }
