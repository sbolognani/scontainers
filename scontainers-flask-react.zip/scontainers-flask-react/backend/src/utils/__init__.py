from .parametrized_decorator import parametrized  # noqa
