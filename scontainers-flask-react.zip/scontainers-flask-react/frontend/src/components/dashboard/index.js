import React, { useState } from "react"
import "./style.css"

export default () => {
  const [state, setState] = useState(0)
  const [history, setHistory] = useState([])
  const fetchNew = async () => {
    const result = await fetch('/api/random/')
    const json = await result.json()
    setState(json.message)
    setHistory(json.data)
  }
  
  return (
    <div style={{width: '100%', textAlign: 'center'}}>
      The fetched state is '{state}'
      <br/>
      <button onClick={fetchNew}>Fetch new</button>
      <table style={{
        marginLeft: 'auto',
        marginRight: 'auto',
        border: '1px solid black'
      }}>
        <tr>
          <th>ID</th>
          <th>VAL</th>
        </tr>
        {history.map(h => {
          return (
            <tr style={{
              borderTop: '1px solid black'
            }}>
              <td style={{paddingLeft: 10, paddingRight: 10}}>{h.key}</td>
              <td style={{paddingLeft: 10, paddingRight: 10}}>{h.val}</td>
            </tr>
          )
        })}
      </table>
    </div>
  )
}
