import "./index.css";
import 'bootstrap/dist/css/bootstrap.min.css';

import React from "react";
import ReactDOM from "react-dom";
import MyComponent from "./components/dashboard"

ReactDOM.render((
  <MyComponent/>
), document.getElementById("root"));
